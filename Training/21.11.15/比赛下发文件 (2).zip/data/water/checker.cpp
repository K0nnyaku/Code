#include "testlib_for_lemons.h"
#include <cstdio>
#include <cctype>
#include <iostream>
#include <cstring>
#include <cstdlib>
#include <queue>
#include <set>
#include <map>
#include <cmath>
#include <vector>
#include <string>
#include <algorithm>

const int N = 1005;
const int lim = 2000000;

bool vis[N], nw[N];
int n, m, ind[N], outd[N], siz, lstsiz;
std::vector<int> vals;
std::vector<std::pair<int, int>> edge[N];
std::map<std::pair<int, int>, bool> mp;

int dfs(int now, int val) {
    if(nw[now]) return 0;
    vis[now] = 1;
    nw[now] = 1;
    if(now == n) {
        vals.push_back(val);
        if((int)vals.size() > siz) return -1;
        nw[now] = 0;
        return 1;
    }
    for(auto v : edge[now]) {
        int tmp = dfs(v.first, val + v.second);
        if(tmp != 1) return tmp;
    }
    nw[now] = 0;
    return 1;
}

std::pair<int, int> judge_graph(InStream& F) {
    n = F.readInt(2, 30, "number of vectices");
    m = F.readInt(1, n * (n - 1) / 2, "number of edges");
    for(int i = 1; i <= n; ++i) edge[i].clear();
    mp.clear(); vals.clear(); siz = 2000000;
    memset(vis, 0, sizeof(vis));
    memset(nw, 0, sizeof(nw));
    memset(ind, 0, sizeof(ind));
    memset(outd, 0, sizeof(outd));
    for(int i = 1; i <= m; ++i) {
        int u, v, c;
        u = F.readInt(1, n, format("vertex \"u\" of path[%d]", i).c_str());
        v = F.readInt(1, n, format("vertex \"v\" of path[%d]", i).c_str());
        if(u == v) {
            return std::make_pair(-3, 0);
        }
        if(mp.find(std::make_pair(u, v)) != mp.end()) {
            return std::make_pair(-2, 0);
        }
        mp[std::make_pair(u, v)] = 1;
        c = F.readInt(1, lim, format("length of path[%d]", i).c_str());
        edge[u].push_back(std::make_pair(v, c));
        ++ind[v], ++outd[u];
    }
    if(ind[1] != 0) return std::make_pair(-5, 0);
    if(outd[n] != 0) return std::make_pair(-6, 0);
    int tmp = dfs(1, 0);
    if(tmp == 0) return std::make_pair(-1, 0);
    if(tmp == -1) return std::make_pair(-8, 0);
    for(int i = 1; i <= n; ++i) if(!vis[i]) return std::make_pair(-7, 0);
    std::sort(vals.begin(), vals.end());
    for(unsigned i = 1; i < vals.size(); ++i) {
        if(vals[i] == vals[i - 1]) return std::make_pair(-4, 0);
    }
    if(!lstsiz) lstsiz = vals.size();
    else {
        if(lstsiz != vals.size()) return std::make_pair(-9, 0);
    }
    return std::make_pair(vals[0], vals.back());
}

int main(int argc, char* argv[]) {
    registerLemonChecker(argc, argv);
    auto std = judge_graph(ans);
    auto par = judge_graph(ouf);
    if(par.first == -9) {
        quitf(_wa, "Wrong Answer The number of paths in participant's graph does not equal to k.");
    }
    if(par.first == -8) {
        quitf(_wa, "Too many paths in participant's graph.");
    }
    if(par.first == -7) {
        quitf(_wa, "Invalid graph G : not connected.");
    }
    if(par.first == -1) {
        quitf(_wa, "Invalid graph G : not a DAG");
        return 0;
    }
    if(par.first == -2) {
        quitf(_wa, "Invalid graph G : has duplicated edge");
        return 0;
    }
    if(par.first == -3) {
        quitf(_wa, "Invalid graph G : has self-loop");
        return 0;
    }
    if(par.first == -4) {
        quitf(_wa, "Wrong Answer There exists two paths in participant's graph that share the same value.");
        return 0;
    }
    if(par.first == -5) {
        quitf(_wa, "Invalid graph G : the In-degree of vectex 1 is not 0.");
        return 0;
    }
    if(par.first == -6) {
        quitf(_wa, "Invalid graph G : the Out-degree of vectex n is not 0.");
        return 0;
    }
    if(std.first < 0) {
        quitf(_fail, "std crashed on this test case :(");
        return 0;
    }
    if(par.first < std.first) {
        quitf(_wa, "Wrong Answer There exists d<v s.t. there's a path of length d in participant's graph.");
        return 0;
    }
    if(par.second > std.second) {
        quitf(_wa, "Wrong Answer There exists d>v+k-1 s.t. there's a path of length d in participant's graph.");
        return 0;    
    }
    if(par.first == std.first && par.second == std.second) {
        quitf(_ok, "ok Correct answer. The ONION allowed you to get scores.");
        return 0;
    }
    quitf(_fail, "The checker is crashed. :(");
    return 0;
}