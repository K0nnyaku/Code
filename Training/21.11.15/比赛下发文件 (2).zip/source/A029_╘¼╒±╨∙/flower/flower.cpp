#include <iostream>
#include <cstdio>
#include <cstring>
#include <cmath>
#include <set>
#define N 1005

using namespace std;

int n, k, a[N];
int ans_sum = 1, ans_xor;
int tot, ver[N], nex[N], head[N];
int f[N][N], d[N], maxd;
int logds;
bool vis[N];
set <int> chose;

void add(int x, int y) {
	ver[++tot] = y;
	nex[tot] = head[x];
	head[x] = tot;
}

void dfs(int x, int fa) {
	for (int i = head[x]; i; i = nex[i]) {
		int y = ver[i];
		if (y != fa) {
			d[y] = d[x] + 1;
			f[y][0] = x;
			maxd = max(maxd, d[y]); 
			dfs(y, x);
		}
	}
}

int lca (int x, int y) {
	if (d[x] < d[y]) swap(x, y);
	for (int i = logds; i >= 0; --i)
		if (d[f[x][i]] >= d[y])
			x = f[x][i];
	if(x == y) return x;
	for (int i = logds; i >= 0; --i)
		if (f[x][i] != f[y][i])
			x = f[x][i], y = f[y][i];
	return f[x][0]; 
}

int main() {
	scanf("%d%d", &n, &k);
	for (int i = 1; i <= k; ++i)
		scanf("%d", &a[i]);
	for (int i = 1; i < n; ++i) {
		int x, y;
		scanf("%d%d", &x, &y);
		add(x, y);
		add(y, x);
	}
	
	dfs(1, 0);
	logds = log(maxd) / log(2) + 1;
	for (int j = 1; j <= logds; ++j)
		for (int i = 1; i <= n; ++i)
			f[i][j] = f[f[i][j - 1]][j - 1];
		
	for (int i = 1; i < 1 << k; ++i) {
		int sum = 0;
		memset(vis, 0, sizeof(vis));
		chose.clear();
		for (int j = 0; j < k; ++j)
			if (i >> j & 1) {
				for (set <int> :: iterator it = chose.begin(); it != chose.end(); ++it) {
					int grand = lca(a[j + 1], *it);
					chose.insert(grand);
				}
				chose.insert(a[j + 1]);
			}
		for (set <int> :: iterator it = chose.begin(); it != chose.end(); ++it) sum += d[*it];
		ans_sum = 1ll * ans_sum * sum % 998244353;
		ans_xor ^= sum;
	}
	
	printf("%d %d", ans_xor, ans_sum);
	return 0;
}
