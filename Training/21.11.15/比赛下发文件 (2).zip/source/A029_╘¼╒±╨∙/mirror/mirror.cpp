#include <iostream>
#include <cstdio>
#define N 1000005
#define mod 67280421310721

using namespace std;

typedef long long ll;
ll n, m, k, a[N], v[N], res, sum;

ll pow(ll x, ll y) {
	ll ans = 0;
	for (int i = 0; i <= 46; ++i) {
		if (y >> i & 1) ans = (ans + x) % mod;
		x = x * x % mod;
		printf("%lld %lld %lld\n", ans, x, y); 
	}
	return ans;
}

void dfs(ll cnt) {
	if (cnt >= k) {
		for (ll i = 1; i <= n; ++i) sum += a[i];
		res++; return;
	}
	for (ll i = 1; i <= n; ++i) {
		a[i] ^= v[cnt % m];
		dfs(cnt + 1);
		a[i] ^= v[cnt % m];
	}
}

int main() {
// 2 2 3 2 3
	scanf("%lld%lld%lld", &n, &m, &k);
	for (int i = 0; i < m; ++i)
		scanf("%lld", &v[i]);
	dfs(0); res /= 2; sum /= 2;
	printf("%lld %lld %lld", res, sum, sum * pow(res, mod - 2) % mod);
	return 0;
}
