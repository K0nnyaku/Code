#include <iostream>
#include <cstdio>
#include <algorithm>
#define N 100005
#define mod 1000000007
using namespace std;

typedef long long ll;
int n, q;
ll a[N], s[N];

int main() {
	scanf("%d%d", &n, &q);
	for (int i = 1; i <= n; ++i)
		scanf("%lld", &a[i]), s[i] = (s[i - 1] + a[i]) % mod;
	while (q--) {
		int op; scanf("%d", &op);
		switch(op) {
			case 1 : {
				int l, r;
				ll x;
				scanf("%d%d%lld", &l, &r, &x);
				for (int i = l; i <= r; ++i)
					if (a[i] <= x) a[i] += x;
				for (int i = l; i <= n; ++i)
					s[i] = (s[i - 1] + a[i]) % mod; 
				break;
			}
			case 2 : {
				int l, r;
				scanf("%d%d", &l, &r);
				printf("%lld\n", s[r] - s[l - 1]);
				break;
			}
			case 3 : {
				int l, r, res = 0;
				ll x;
				scanf("%d%d%lld", &l, &r, &x);
				for (int i = l; i <= r; ++i)
					if (a[i] <= x) res++;
				printf("%d\n", res);
				break;
			}
		}
	}
	return 0;
} 
