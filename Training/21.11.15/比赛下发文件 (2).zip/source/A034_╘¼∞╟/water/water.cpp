#include<bits/stdc++.h>
using namespace std;
int k,v,ans[100005],tot,n,m,vi[35][35];
int d1[100005],d2[100005],d3[100005],cnt;
void add(int x)
{
	int D[100005],p=0;
	while(x)
	{
		if(x%2)
		D[++p]=1;
		else
		D[++p]=0;
		x/=2;
	}
	int pre=0;
	for(int i=1;i<=n;i++)
	{
		if(D[i]==1&&pre!=0&&!vi[pre+1][i+1])
		{
			int num=pow(2,i-1);
			d1[++cnt]=pre+1,d2[cnt]=i+1,d3[cnt]=num;
			vi[pre+1][i+1]=1;
			pre=i;
			m++;
		}
		if(D[i]==1)
		pre=i;
	}
	if(!vi[pre+1][n])
	{
		d1[++cnt]=pre+1,d2[cnt]=n,d3[cnt]=0,vi[pre+1][n]=1;
		m++;
	}
}
int main()
{
	freopen("water.in","r",stdin);
	freopen("water.out","w",stdout);
	cin>>k>>v;
	n=21;
	int num=k+v-1;
	for(int i=2;i<=20;i++)
	{
//		cout<<1<<" "<<i<<" "<<pow(2,i-1)<<endl;
		int ppow=pow(2,i-2);
		d1[++cnt]=1;
		d2[cnt]=i;
		d3[cnt]=ppow;
		m++;
	}
	for(int i=v;i<=k+v-1;i++)
	{
		add(i);
	}
	cout<<n<<" "<<m<<endl;
	for(int i=1;i<=m;i++)
	{
		if(d1[i]==3&&d2[i]==21&&v==3)
		{
			cout<<2<<" "<<21<<" "<<2<<endl;
			continue;
		}
		cout<<d1[i]<<" "<<d2[i]<<" "<<d3[i]<<endl;
	}
}
