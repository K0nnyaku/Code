#include<bits/stdc++.h>
using namespace std;
const int mod=1e9+7;
int n,m;
struct ST
{
	int l,r;
	long long sum,add,maxx,minn;
}t[400005];
long long a[100005];
inline long long read()
{
	char v=getchar();
	long long x=0,f=1;
	while(!isdigit(v))
	{
		if(v=='-')
		f=-1;
		v=getchar();
	}
	while(isdigit(v))
	{
		x=x*10+v-'0';
		v=getchar();
	}
	return x*f;
}
void build(int p,int l,int r)
{
	t[p].l=l,t[p].r=r;
	if(l==r)
	{
		t[p].sum=a[l];
		t[p].minn=a[l];
		t[p].maxx=a[l];
		return;
	}
	int mid=l+r>>1;
	build(p*2,l,mid);
	build(p*2+1,mid+1,r);
	t[p].sum=t[p*2].sum+t[p*2+1].sum;
	t[p].maxx=max(t[p*2].maxx,t[p*2+1].maxx);
	t[p].minn=min(t[p*2].minn,t[p*2+1].minn);
}
void spread(int p)
{
	if(t[p].add)
	{
		t[p*2].add+=t[p].add;
		t[p*2+1].add+=t[p].add;
		t[p*2].maxx+=t[p].add;
		t[p*2].minn+=t[p].add;
		t[p*2+1].maxx+=t[p].add;
		t[p*2+1].minn+=t[p].add;
		t[p*2].sum+=t[p].add*(t[p*2].r-t[p*2].l+1);
		t[p*2+1].sum+=t[p].add*(t[p*2+1].r-t[p*2+1].l+1);
		t[p].add=0;
	}
}
void change(int p,int l,int r,long long d)
{
	if(t[p].l==t[p].r)
	{
		if(t[p].sum<=d)
		{
			t[p].sum+=d*((long long)(t[p].r-t[p].l+1));
			t[p].minn+=d;
			t[p].maxx+=d;
			t[p].add+=d;
		}
		return;
	}
	spread(p);
	int mid=t[p].l+t[p].r>>1;
	if(l<=mid)
	change(p*2,l,r,d);
	if(r>mid)
	change(p*2+1,l,r,d);
	t[p].sum=t[p*2].sum+t[p*2+1].sum;
	t[p].maxx=max(t[p*2].maxx,t[p*2+1].maxx);
	t[p].minn=min(t[p*2].minn,t[p*2+1].minn);
}
long long ask1(int p,int l,int r)
{
	if(t[p].l>=l&&t[p].r<=r)
	{
		return t[p].sum%mod;
	}
//	spread(p);
	int mid=t[p].l+t[p].r>>1;
	long long val=0;
	if(l<=mid)
	val=(val%mod+ask1(p*2,l,r)%mod)%mod;
	if(r>mid)
	val=(val%mod+ask1(p*2+1,l,r)%mod)%mod;
	return val;
}
int ask2(int p,int l,int r,long long d)
{
	if(t[p].l==t[p].r)
	{
		if(t[p].sum<=d)
		return 1;
		else
		return 0;
	}
	if(t[p].l>=l&&t[p].r<=r)
	{
		if(t[p].minn>d)
		return 0;
		if(t[p].maxx<=d)
		return t[p].r-t[p].l+1;
	}
	int mid=t[p].l+t[p].r>>1;
	int val=0;
	if(l<=mid)
	val+=ask2(p*2,l,r,d);
	if(r>mid)
	val+=ask2(p*2+1,l,r,d);
	return val;
}
int main()
{
	freopen("moon.in","r",stdin);
	freopen("moon.out","w",stdout);
	n=read(),m=read();
	for(int i=1;i<=n;i++)
	{
		a[i]=read();
	}
	build(1,1,n);
	while(m--)
	{
//		cout<<1<<endl;
		int s;
		s=read();
		if(s==1)
		{
			long long x,y,d;
			x=read(),y=read(),d=read();
			change(1,x,y,d);
		}
		if(s==2)
		{
			long long x,y;
			x=read(),y=read();
			cout<<ask1(1,x,y)<<endl;
		}
		if(s==3)
		{
			long long x,y,d;
			x=read(),y=read(),d=read();
			cout<<ask2(1,x,y,d)<<endl;
		}
	}
}
