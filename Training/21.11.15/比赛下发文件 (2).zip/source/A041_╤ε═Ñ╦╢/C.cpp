#include<iostream>
#include<cstdio>
using namespace std;
int k,v;
int main()
{
	freopen("water.in","r",stdin);
	freopen("water.out","w",stdout);
	cin>>k>>v;
	int n=k+v,m=n+k-2;
	cout<<n<<' '<<m<<'\n';
	for(int i=1;i<n;i++)
		cout<<i<<' '<<i+1<<' '<<1<<'\n';
	cout<<1<<' '<<n<<' '<<v<<'\n';
	int cnt=0;
	for(int i=n-1;;i--)
	{
		if(cnt==k-2) break;
		cout<<1<<' '<<i<<' '<<v<<'\n';
		cnt++;
	}
	return 0;
}
