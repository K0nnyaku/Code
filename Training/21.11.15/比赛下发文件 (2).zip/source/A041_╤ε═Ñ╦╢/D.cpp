#include<iostream>
#include<cstdio>
#include<bits/stdc++.h>
#define ull unsigned long long
using namespace std;
const int MAXN=1e5+5,mod=1e9+7;
ull a[MAXN],b[MAXN],n,q;
bool sb1;
inline ull read(){
	ull x=0,f=1;char ch=getchar();
	while(!isdigit(ch)){if(ch=='-')f=-1;ch=getchar();}
	while(isdigit(ch)){x=x*10+ch-'0';ch=getchar();}
	return x*f;
}
int main()
{
	freopen("moon2.in","r",stdin);
	n=read(),q=read();
	if(n<=5000 && q<=5000) sb1=1;
	if(sb1)
	{
		for(int i=1;i<=n;i++) a[i]=read();
		for(int i=1;i<=q;i++)
		{
			int op=read(),l=read(),r=read();
			if(op==1)
			{
				ull x=read();
				for(int j=l;j<=r;j++)
				{
					if(a[j]<=x) a[j]+=x;
				}
			}
			if(op==2)
			{
				ull ans=0;
				for(int j=l;j<=r;j++)
				{
					ans=(ans+a[j])%mod;
				}
				cout<<ans<<'\n';
			}
			if(op==3)
			{
				ull x=read(),ans=0;
				for(int j=l;j<=r;j++)
				{
					if(a[j]<=x) ans++;
				}
				cout<<ans<<'\n';
			}
		}
		return 0;
	}
	return 0;
}
