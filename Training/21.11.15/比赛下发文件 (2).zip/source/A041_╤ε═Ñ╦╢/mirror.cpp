#include<iostream>
#include<cstdio>
#include<bits/stdc++.h>
#define int long long
using namespace std;
const int MAXN=105,mod=67280421310721;
int n,m,k,a[MAXN],x[MAXN],cnt,ans;
inline int read(){
	int x=0,f=1;char ch=getchar();
	while(!isdigit(ch)){if(ch=='-')f=-1;ch=getchar();}
	while(isdigit(ch)){x=x*10+ch-'0';ch=getchar();}
	return x*f;
}
int ksc(int a,int b,int p)
{
	if(b==0) return 0;
	int c=ksc(a,b/2,p);
	c=(c+c)%p;
	if(b%2==1) c=(c+a)%p;
	return c;
}
int ksm(int a,int b)
{
	int res=1;
	while(b)
	{
		if(b&1) res=ksc(res,a,mod)%mod;
		a=ksc(a,a,mod)%mod;
		b>>=1;
	}
	return res%mod;
}
void dfs(int pos)
{
//	cout<<"pos: "<<pos<<endl;
	if(pos==k)
	{
		cnt++;
		for(int i=1;i<=n;i++) ans=(ans+a[i])%mod;
		return;
	}
	for(int i=1;i<=n;i++)
	{
		int temp=a[i];
		a[i]=(a[i]^x[pos%m])%mod;
//		printf("x[%d]: %d\n",pos%m,x[pos%m]);
//		printf("a[%d]: %d\n",i,a[i]);
		dfs(pos+1);
		a[i]=temp;
	}
}
signed main()
{
	freopen("mirror.in","r",stdin);
	freopen("mirror.out","w",stdout);
	n=read(),m=read(),k=read();
	for(int i=0;i<m;i++) x[i]=read();
	dfs(0);
	cout<<ans*ksm(cnt,mod-2)%mod;
	return 0;
}
/*
cout:
60606237081805
*/
