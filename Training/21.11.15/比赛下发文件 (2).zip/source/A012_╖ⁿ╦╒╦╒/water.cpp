#include <cctype>
#include <cstdio>
#include <iostream>

inline int readInt() {
  int ans = 0, c, f = 1;
  while (!isdigit(c = getchar()))
    if (c == '-') f = -1;
  do ans = ans * 10 + c - '0';
  while (isdigit(c = getchar()));
  return ans * f;
}

const int N = 1e5+3, mod = 1e9+7;

int k, v;

inline void Get_twenty_pts() {
  printf("%d %d\n", k + 1, k + k - 1);
  for (int i = 1; i <= k; ++i)
  	printf("%d %d %d\n", i, k + 1, v);
  for (int i = 2; i <= k; ++i)
  	printf("%d %d %d\n", 1, i, i - 1);
}

int main() {
  freopen("water.in", "r", stdin);
  freopen("water.out", "w", stdout);
  k = readInt(), v = readInt();
  //if(k < 30) 
  Get_twenty_pts();
  fclose(stdin);
  fclose(stdout);
  return 0;
}
