#include <cctype>
#include <cstdio>
#include <iostream>

typedef long long LL;

inline LL readInt() {
  LL ans = 0, c, f = 1LL;
  while (!isdigit(c = getchar()))
    if (c == '-') f = -1;
  do ans = ans * 10 + c - '0';
  while (isdigit(c = getchar()));
  return ans * f;
}

const int N = 1e5+3, mod = 1e9+7;

LL n, q, a[N], op, l, r, x;

int main() {
  freopen("moon.in", "r", stdin);
  freopen("moon.out", "w", stdout);
  n = readInt(), q = readInt();
  for (int i = 1; i <= n; ++i) a[i] = readInt();
  while (q--) {
  	op = readInt();
  	if (op == 1) {
  	  l = readInt(), r = readInt(), x = readInt();
  	  for (int i = l; i <= r; ++i) if (a[i] <= x) {
  	  	a[i] += x;
  	  	a[i] %= mod;
	  }
	}
	if (op == 2) {
	  l = readInt(), r = readInt();
	  LL s = 0;
	  for (int i = l; i <= r; ++i) {
	  	s += a[i];
	  	s %= mod;
	  }
	  printf("%lld\n", s);
	}
	if (op == 3) {
	  l = readInt(), r = readInt(), x = readInt();
	  LL s = 0;
	  for (int i = l; i <= r; ++i) {
	  	if (a[i] <= x) ++s;
	  }
	  printf("%lld\n", s);
	}
  }
  fclose(stdin);
  fclose(stdout);
  return 0;
}
/*
5 5
2 3 4 3 4
1 2 4 3
2 2 5
3 1 4 4
1 1 3 3
2 1 5
*/
