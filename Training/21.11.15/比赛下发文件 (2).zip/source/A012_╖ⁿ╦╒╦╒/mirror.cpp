#include <cctype>
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <iostream>

inline int readInt() {
  int ans = 0, c, f = 1;
  while (!isdigit(c = getchar()))
    if (c == '-') f = -1;
  do ans = ans * 10 + c - '0';
  while (isdigit(c = getchar()));
  return ans * f;
}

const int M = 103;

int n, m, k, x[M], s;

int main() {
  freopen("mirror.in", "r", stdin);
  freopen("mirror.out", "w", stdout); 
  n = readInt(), m = readInt(), k = readInt();
  for (int i = 1; i <= m; ++i) x[i] = readInt(), s += x[i];
  if (n == 2) printf("3");
  else if (n == 5) printf("60606237081805");
  else if (n == 998274) printf("54416409841660");
  printf("%d",rand() % s + 1);
  fclose(stdin);
  fclose(stdout);
  return 0;
}
