#include<iostream>
using namespace std;
int n,m,k,v;
int erfen(int num){
	int l=0,r=30;
	while(l<r){
		int mid=(l+r)>>1;
		if(num<=(1<<mid)) r=mid;
		else l=mid+1;
	}
	return l;
}
int lowbit(int x){
	return x&(-x);
}
int stack1[10001],stack2[10001],stack3[10001],top;
void add(int f,int t,int v){
	stack1[top]=f;
	stack2[top]=t;
	stack3[top]=v;
	top++;
}
int main()
{
	freopen("water.in","r",stdin);
	freopen("water.out","w",stdout);
	cin>>k>>v;
	n=erfen(k);n+=2;
	cout<<n<<' ';
	for(int i=1;i<=n-1;i++){
		for(int j=i+1;j<=n-1;j++){
			add(i,j,1);
		}
	}
	add(1,n,v);
	int sum=k-1;
	while(sum){
		int x=lowbit(sum),cnt=0;
		while(x) x/=2,cnt++;
		cnt++;
		add(cnt,n,k+v-1-cnt+1);
		sum-=lowbit(sum);
	}
	cout<<top<<'\n';
	for(int i=0;i<top;i++)
		cout<<stack1[i]<<" "<<stack2[i]<<" "<<stack3[i]<<'\n';
	return 0;
}
