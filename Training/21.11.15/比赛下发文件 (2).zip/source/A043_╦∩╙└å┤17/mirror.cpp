#include<iostream>
using namespace std;
unsigned long long a[10001],x[10001],ans,n,k,m,P=67280421310721;
unsigned long long ksc(unsigned long long a,unsigned long long b){
	if(b==0) return 0;
	unsigned long long c=ksc(a,b/2)%P;
	c=(c+c)%P;
	if(b%2==1) c=(c+a)%P;
	return c;
}
unsigned long long ksm(unsigned long long a,unsigned long long b){
	unsigned long long ans=1;
	while(b){
		if(b&1) ans=ksc(ans,a)%P;
		a=ksc(a,a)%P;
		b>>=1;
	}
	return ans;
}
unsigned long long invi(unsigned long long a,unsigned long long b){
	return a%P*ksm(b,P-2)%P;
}
void dfs(unsigned long long deep){
	if(deep==k+1){
		unsigned long long sum=0;
		for(unsigned long long i=1;i<=n;i++)
			sum+=a[i];
		ans=(ans+invi(sum%P,ksm(n,k))%P)%P;
		return ;
	}
	for(unsigned long long i=1;i<=n;i++){
		unsigned long long ce=a[i];
		a[i]=a[i]^x[deep%m];
		dfs(deep+1);
		a[i]=ce;
	}
}
int main(){
	freopen("mirror.in","r",stdin);
	freopen("mirror.out","w",stdout);
	cin>>n>>m>>k;
	for(unsigned long long i=0;i<m;i++){
		cin>>x[i];
	}
	dfs(1);
	cout<<ans<<endl;
	return 0;
}
