#include<bits/stdc++.h>
using namespace std;
const unsigned long long P=1e9+7;
unsigned long long n,q,a[1000001],len;
struct asks{
	unsigned long long time;
	unsigned long long op,l,r;
	unsigned long long ans;
	unsigned long long x;
	unsigned long long id;
} s[1000001];
unsigned long long top=0,ans2=0,ans3=0,p;
unsigned long long abs(unsigned long long x){
	return (x>0)?x:-x;
}
bool cmp1(asks x,asks y){
	if(x.time!=y.time) return x.time<y.time;
	if(abs(x.l-y.l)<=len) return x.r<y.r;
	else return x.l<y.l;
}
bool cmp2(asks x,asks y){
	return x.id<y.id;
}
unsigned long long add(unsigned long long x){
	ans2=(ans2+a[x])%P;
}
unsigned long long del(unsigned long long x){
	ans2=(ans2+P-a[x])%P;
}
int main()
{
	freopen("moon.in","r",stdin);
	freopen("moon.out","w",stdout);
	cin>>n>>q;
	len=sqrt(n);
	for(unsigned long long i=1;i<=n;i++) cin>>a[i];
	for(unsigned long long i=1;i<=q;i++){
		cin>>s[i].op>>s[i].l>>s[i].r;
		if(s[i].op==1) top++;
		s[i].id=i;s[i].time=top;
		if(s[i].op!=2) cin>>s[i].x;
		if(s[i].op==1) top++;
	}
	sort(s+1,s+1+q,cmp1);
	unsigned long long l=1,r=1;add(1);
	for(unsigned long long i=1;i<=q;i++){
		unsigned long long tl=s[i].l,tr=s[i].r;p=s[i].x;
		if(s[i].op==1){
			for(unsigned long long j=tl;j<=tr;j++){
				if(a[j]<=p){
					a[j]+=p;
				}
			}
			
		}
		if(s[i].op==2){
			ans2=0;
			for(unsigned long long j=tl;j<=tr;j++) ans2=(ans2+a[j])%P;
			s[i].ans=ans2;
		}
		if(s[i].op==3){
			unsigned long long cnt=0;
			for(unsigned long long j=tl;j<=tr;j++){
				if(a[j]<=p) cnt++;
			}
			s[i].ans=cnt;
		}
	}
	sort(s+1,s+1+q,cmp2);
	for(unsigned long long i=1;i<=q;i++){
		if(s[i].op==1) continue;
		cout<<s[i].ans<<endl;
	}
	return 0;
}
