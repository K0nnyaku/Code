#include <cstdio>
#include <cctype>
#include <iostream>
#include <cstring>
#include <cstdlib>
#include <queue>
#include <set>
#include <map>
#include <cmath>
#include <vector>
#include <string>
#include <algorithm>

const int N = 100005;
const int M = 30;

int n, k;
typedef long long ll;
const ll mod = 998244353;

inline void read(int &x) {
	register char ch = 0; register bool w = 0;
	for(x = 0; !std::isdigit(ch); w |= ch == '-', ch = getchar());
	for(; std::isdigit(ch); x = x * 10 + ch - '0', ch = getchar());
	(w) && (x = -x);
	return;
}

int pi[M];
std::vector<int> edge[N];
int lca[M][M], sha[M][M];
short mpbit[(1 << 26) + 5];
int res[(1 << 27) + 5];
int dep[N], fa[N], top[N], siz[N], son[N], id[N], dfn;

void dfs1(int now, int faa) {
    fa[now] = faa, dep[now] = dep[faa] + 1, siz[now] = 1;
    id[now] = ++dfn;
    int maxs = -1;
    for(auto v : edge[now]) {
        if(v == faa) continue;
        dfs1(v, now);
        siz[now] += siz[v];
        if(siz[v] > maxs) maxs = siz[v], son[now] = v;
    }
}
void dfs2(int now, int tp) {
    top[now] = tp;
    if(!son[now]) return;
    dfs2(son[now], tp);
    for(auto v : edge[now]) {
        if(v == fa[now] || v == son[now]) continue;
        dfs2(v, v);
    }
}
int LCA(int x, int y) {
    while(top[x] != top[y]) {
        if(dep[top[x]] < dep[top[y]]) std::swap(x, y);
        x = fa[top[x]];
    }
    return dep[x] < dep[y] ? x : y;
}

int main() {
    freopen("flower.in", "r", stdin);
    freopen("flower.out", "w", stdout);
    read(n), read(k);
    for(int i = 1; i <= k; ++i) {
        read(pi[i]);
    }
    for(int i = 1; i < n; ++i) {
        int u, v; read(u), read(v);
        edge[u].push_back(v), edge[v].push_back(u);
    }
    dep[0] = -1;
    dfs1(1, 0), dfs2(1, 1);
    dep[0] = 0;
    std::sort(pi + 1, pi + k + 1, [&](const int &x, const int &y) {
        return id[x] > id[y];
    });
    for(int i = 1; i <= k; ++i) 
        for(int j = 1; j <= k; ++j) lca[i][j] = LCA(pi[i], pi[j]);
    for(int i = 1; i <= k; ++i) {
        mpbit[(1 << (i - 1))] = i;
        for(int j = 1; j <= k; ++j) {
            int nowl = lca[i][j];
            for(int p = 1; p <= k; ++p) if(lca[i][p] == nowl) 
                sha[i][j] |= (1 << (p - 1)), sha[i][p] |= (1 << (j - 1));
        }
    }
#define lowbit(x) (x & -x)
    int ans = 0, mul = 1;
    for(int msk = 1; msk < (1 << k); ++msk) {
        int lowb = lowbit(msk);
        int lst = msk ^ lowb, nowp = mpbit[lowb];
        int lstp = mpbit[lowbit(lst)];
        res[msk] = res[lst] + (!(sha[lstp][nowp] & lst)) * dep[lca[lstp][nowp]] + dep[pi[nowp]];
        ans ^= res[msk];
        mul = 1ll * mul * res[msk] % mod;
    }
    printf("%d %d\n", ans, mul);
    return 0;
}