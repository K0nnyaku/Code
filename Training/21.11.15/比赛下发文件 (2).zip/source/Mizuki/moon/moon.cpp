#include <cstdio>
#include <cctype>
#include <iostream>
#include <cstring>
#include <cstdlib>
#include <queue>
#include <set>
#include <map>
#include <cmath>
#include <vector>
#include <string>
#include <algorithm>

const int N = 200005;
const int S = 5005;
typedef long long ll;
const ll mod = 1e9 + 7;

inline void read(int &x) {
	register char ch = 0; register bool w = 0;
	for(x = 0; !std::isdigit(ch); w |= ch == '-', ch = getchar());
	for(; std::isdigit(ch); x = x * 10 + ch - '0', ch = getchar());
	(w) && (x = -x);
	return;
}
inline void read(ll &x) {
	register char ch = 0; register bool w = 0;
	for(x = 0; !std::isdigit(ch); w |= ch == '-', ch = getchar());
	for(; std::isdigit(ch); x = x * 10 + ch - '0', ch = getchar());
	(w) && (x = -x);
	return;
}

struct node {
    ll val; int id;
    bool operator < (const node &X) const {
        if(val != X.val) return val < X.val;
        else return id < X.id;
    }
} tmp[S];

ll ai[N];
int n, q, li[N], ri[N], belong[N], limit, siz, cntb, cntt;

struct blocks {
    int el, er, pl, pr, lim;
    node t[S], san[65];
    ll sum;
    void build_block(int num) {
        pl = 1, pr = 0;
        for(int i = el; i <= er; ++i) {
            t[++pr].id = i, t[pr].val = ai[i];
            sum = (sum + ai[i]) % mod;
            belong[i] = num;
        }
        std::sort(t + 1, t + pr + 1);
    }
    int find_loc(ll x) {
        int nowl = pl, nowr = pr, ans = -1;
        while(nowl <= nowr) {
            int mid = (nowl + nowr) >> 1;
            if(t[mid].val <= x) ans = mid, nowl = mid + 1;
            else nowr = mid - 1;
        }
        return ans;
    }
    int query_rank(ll x) {
        int result = 0;
        for(int i = 1; i <= lim; ++i) if(san[i].val <= x) ++result;
        int anss = find_loc(x);
        if(anss == -1) return result;
        else return result + (anss - pl + 1);
    }
    ll query_sum() {
        return sum % mod;
    }
    int merge(node *result, node *q1, node *q2, int l1, int r1, int l2, int r2, bool flag2 = 0) {
        if(flag2) std::sort(q2 + 1, q2 + r2 + 1);
        int pall = 1, p1 = l1, p2 = l2;
        while(p1 <= r1 && p2 <= r2) {
            if(q1[p1] < q2[p2]) tmp[pall] = q1[p1], ++p1, ++pall;
            else tmp[pall] = q2[p2], ++p2, ++pall;
        }
        while(p1 <= r1) tmp[pall] = q1[p1], ++p1, ++pall;
        while(p2 <= r2) tmp[pall] = q2[p2], ++p2, ++pall;
        for(int i = 1; i < pall; ++i) result[i] = tmp[i];
        return pall - 1;
    }
    void reset() {
        if(!lim) return;
        pr = merge(t, t, san, pl, pr, 1, lim, 1);
        pl = 1, lim = 0;
    }
    void merge1(int ul, ll x) {
        int newr = merge(tmp, t, t, pl, ul, ul + 1, pr);
        for(int i = 1; i <= newr; ++i) t[i] = tmp[i];
        pl = 1, pr = newr;
    }
    void update(ll x) {
        for(int i = 1; i <= lim; ++i) 
            if(san[i].val <= x) san[i].val += x, sum = (sum + x) % mod;
        int cr = find_loc(x);
        if(cr == -1) return;
        if(cr - pl + 1 + lim < limit) {
            for(int i = pl; i <= cr; ++i) 
                san[++lim].id = t[i].id, san[lim].val = t[i].val + x, sum = (sum + x) % mod;
            pl = cr + 1;
        } else {
            for(int i = pl; i <= cr; ++i) t[i].val += x, sum = (sum + x) % mod;
            merge1(cr, x); // [pl, cr] & [cr + 1, pr]
            reset();
        }
    }
    void upd2(int l, int r, ll x) {
        for(int i = 1; i <= lim; ++i) {
            if(l <= san[i].id && san[i].id <= r) 
                if(san[i].val <= x) san[i].val += x, sum = (sum + x) % mod;
        }
        static node que1[S], que2[S];
        int p1 = 0, p2 = 0;
        for(int i = pl; i <= pr; ++i) {
            if(l <= t[i].id && t[i].id <= r)
                if(t[i].val <= x) 
                    que1[++p1].id = t[i].id, que1[p1].val = t[i].val + x, sum = (sum + x) % mod;
                else que2[++p2] = t[i];
            else que2[++p2] = t[i];
        }
        if(p1 + lim < limit) {
            for(int i = 1; i <= p1; ++i) san[++lim] = que1[i];
            for(int i = 1; i <= p2; ++i) t[i] = que2[i];
            pl = 1, pr = p2;
            return;
        }
        if(lim > 0) {
            if(p1 < p2) {
                p1 = merge(tmp, que1, san, 1, p1, 1, lim, 1);
                for(int i = 1; i <= p1; ++i) que1[i] = tmp[i];
            } else {
                p2 = merge(tmp, que2, san, 1, p2, 1, lim, 1);
                for(int i = 1; i <= p2; ++i) que2[i] = tmp[i];
            }
            lim = 0;
        }
        pr = merge(t, que1, que2, 1, p1, 1, p2);
        pl = 1;
    }
    int qrank2(int l, int r, ll x) {
        int result = 0;
        for(int i = 1; i <= lim; ++i) 
            if(l <= san[i].id && san[i].id <= r) result += (san[i].val <= x);
        for(int i = pl; i <= pr; ++i) 
            if(l <= t[i].id && t[i].id <= r) result += (t[i].val <= x);
        return result;
    }
    ll qsum2(int l, int r) {
        ll result = 0;
        for(int i = 1; i <= lim; ++i) 
            if(l <= san[i].id && san[i].id <= r) result = (result + san[i].val) % mod;
        for(int i = pl; i <= pr; ++i) 
            if(l <= t[i].id && t[i].id <= r) result = (result + t[i].val) % mod;
        return result;
    }
};
blocks B[2000];

void up1(int l, int r, ll x) {
    int bl = belong[l], br = belong[r];
    if(bl == br) {
        B[bl].upd2(l, r, x);
        return;
    }
    if(l == B[bl].el) B[bl].update(x);
    else B[bl].upd2(l, r, x);
    if(r == B[br].er) B[br].update(x);
    else B[br].upd2(l, r, x);
    for(int i = bl + 1; i < br; ++i) B[i].update(x);
}

int query1(int l, int r, ll x) {
    int bl = belong[l], br = belong[r], resl = 0;
    if(bl == br) return B[bl].qrank2(l, r, x);
    if(l == B[bl].el) resl += B[bl].query_rank(x);
    else resl += B[bl].qrank2(l, r, x);
    if(r == B[br].er) resl += B[br].query_rank(x);
    else resl += B[br].qrank2(l, r, x);
    for(int i = bl + 1; i < br; ++i) resl += B[i].query_rank(x);
    return resl;
}

ll query2(int l, int r) {
    int bl = belong[l], br = belong[r]; ll resl = 0;
    if(bl == br) return B[bl].qsum2(l, r);
    if(l == B[bl].el) resl = (resl + B[bl].query_sum()) % mod;
    else resl = (resl + B[bl].qsum2(l, r)) % mod;
    if(r == B[br].er) resl = (resl + B[br].query_sum()) % mod;
    else resl = (resl + B[br].qsum2(l, r)) % mod;
    for(int i = bl + 1; i < br; ++i) resl = (resl + B[i].query_sum()) % mod;
    return resl % mod;
}

int main() {
    freopen("moon.in", "r", stdin);
    freopen("moon.out", "w", stdout);
    read(n), read(q);
    for(int i = 1; i <= n; ++i) read(ai[i]);
    siz = sqrt((double)n * 4);
    limit = 50;
    for(int i = 1; i <= n; i += siz) {
        int rr = std::min(n, i + siz - 1);
        B[++cntb].el = i, B[cntb].er = rr;
        B[cntb].build_block(cntb);
    }
    while(q--) {
        int opt; read(opt);
        if(opt == 1) {
            int l, r; ll x; read(l), read(r), read(x);
            up1(l, r, x);
        } else if(opt == 2) {
            int l, r; read(l), read(r);
            printf("%lld\n", query2(l, r));
        } else {
            int l, r; ll x; read(l), read(r), read(x);
            printf("%d\n", query1(l, r, x));
        }
    }
    return 0;
}