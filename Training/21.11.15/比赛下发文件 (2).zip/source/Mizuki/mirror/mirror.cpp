#include <cstdio>
#include <cctype>
#include <iostream>
#include <cstring>
#include <cstdlib>
#include <queue>
#include <set>
#include <map>
#include <cmath>
#include <vector>
#include <string>
#include <algorithm>

const int N = 1000005;

typedef long long ll;
const ll mod = 67280421310721ll;

ll n, k, count[N];
int ai[N], m;

inline ll mul(ll a, ll b) {
    ll ans = 0;
    for(; b; a = (a + a) % mod, b >>= 1) if(b & 1) ans = (ans + a) % mod;
    return ans;
}
inline ll quick_pow(ll a, ll b) {
    if(b < 0) return 0;
    ll ans = 1;
    for(; b; b >>= 1, a = mul(a, a)) if(b & 1) ans = mul(ans, a);
    return ans;
}

ll solve(ll n1, ll k1) {
    ll inv_n1 = quick_pow(n1, mod - 2);
    ll alpha = mul((n1 - 2 + mod) % mod, inv_n1);
    ll det = quick_pow((alpha - 1 + mod) % mod, mod - 2);
    ll g = quick_pow(alpha, k1 - 1);
    ll p = mul(g, det + 1);
    return (p - det + mod) % mod;
}

int main() {
    freopen("mirror.in", "r", stdin);
    freopen("mirror.out", "w", stdout);
    scanf("%lld %d %lld", &n, &m, &k);
    for(int i = 0; i < m; ++i) {
        scanf("%d", ai + i);
        int tmp = ai[i], now = 0;
        ll ki = k / (ll)m;
        if(k % m >= i + 1) ++ki;
        while(tmp) count[now] = (count[now] + ki * (tmp & 1)) % mod, tmp >>= 1, ++now;
    }
    ll ans = 0;
    for(int i = 0; i <= 30; ++i) {
        if(count[i]) ans = (ans + mul((1ll << i), solve(n, count[i]))) % mod;
    }
    printf("%lld\n", ans);
    return 0;
}