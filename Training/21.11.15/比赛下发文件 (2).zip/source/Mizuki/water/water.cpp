#include <cstdio>
#include <cctype>
#include <iostream>
#include <cstring>
#include <cstdlib>
#include <queue>
#include <set>
#include <map>
#include <cmath>
#include <vector>
#include <string>
#include <algorithm>
 
const int N = 1000005;
 
int n, t, L, R;
typedef long long ll;
 
inline void read(int &x) {
	register char ch = 0; register bool w = 0;
	for(x = 0; !std::isdigit(ch); w |= ch == '-', ch = getchar());
	for(; std::isdigit(ch); x = x * 10 + ch - '0', ch = getchar());
	(w) && (x = -x);
	return;
}
 
struct threepair {
    int u, v, w;
};
 
std::vector<threepair> ans;
 
int calc(int x) {
    int res = 0;
    while((1 << res) < x) ++res;
    if((1 << res) > x) --res;
    return res;
}
 
void construct1(int x) {
    ans.push_back({1, 2, 1});
    n = 2;
    for(int i = 2; i <= x + 1; ++i) {
        ans.push_back({1, n + 1, 1});
        for(int j = 2; j <= n; ++j) {
            ans.push_back({j, n + 1, 1 << (j - 2)});
        }
        n += 1;
    }
}
 
void construct2(int x, int cnt) {
    ans.push_back({1, n + 1, 1});
    for(int i = 0; i <= cnt; ++i) { // 1 ~ 2 ** i : end at vertex i + 2
        if(x & (1 << i)) {
            int val = x & ((1 << i) - 1);
            ans.push_back({i + 2, n + 1, 1 + val});
        }
    }
    n += 1;
}
 
void construct3(int x) {
    ans.push_back({n, n + 1, x});
    n += 1;
}
 
int main() {
    freopen("water.in", "r", stdin);
    freopen("water.out", "w", stdout);
    int k, v; read(k), read(v);
    L = v, R = v + k - 1;
    R = R - L + 1;
    int count = calc(R - 1);
    construct1(count);
    if(R > 1) construct2(R - 1, count);
    if(L > 1) construct3(L - 1);
    printf("%d %lu\n", n, ans.size());
    for(auto v : ans) printf("%d %d %d\n", v.u, v.v, v.w);
    return 0;
}