#include<bits/stdc++.h>
using namespace std;
int k,v;
int main()
{
	freopen("moon.in","r",stdin);
	freopen("moon.out","w",stdout);
	int num;
	cin>>k>>v;
	if(v==1)//20
	{
		if(k==1)
		{
			cout<<2<<" "<<1<<endl;
			cout<<1<<" "<<2<<" "<<1<<endl;
		}
		else
		{
			cout<<k+1<<" "<<2*k-1<<endl;
			cout<<1<<" "<<k+1<<" "<<1<<endl;
			cout<<1<<" "<<2<<" "<<1<<endl;
			cout<<2<<" "<<k+1<<" "<<k+v-2<<endl;
			for(int i=3;i<=k;i++)
			{
				cout<<i-1<<" "<<i<<" "<<1<<endl;
				cout<<i<<" "<<k+1<<" "<<1<<endl;
			}
			cout<<1<<" "<<k<<" "<<1<<endl;
			cout<<k<<" "<<k+1<<" "<<1<<endl;
		} 
	}
	else//30
	{
		cout<<k+1<<" "<<2*k-1<<endl;
			cout<<1<<" "<<k+1<<" "<<v<<endl;
			cout<<1<<" "<<2<<" "<<1<<endl;
			cout<<2<<" "<<k+1<<" "<<k+v-2<<endl;
			for(int i=3;i<=k;i++)
			{
				if(i!=v)
				{
				cout<<i-1<<" "<<i<<" "<<1<<endl;
				cout<<i<<" "<<k+1<<" "<<1<<endl;
				}	
			}
			cout<<1<<" "<<v<<" "<<1<<endl;
			cout<<v<<" "<<k+1<<" "<<k<<endl; 
	}
	return 0;
}
