#include<bits/stdc++.h>
using namespace std;
const int maxn=500000;
const int MOD=1e9+7;
long long n,a[maxn],q,ans;
int main()
{
	freopen("moon.in","r",stdin);
	freopen("moon.out","w",stdout);
	cin>>n>>q;
	for(int i=1;i<=n;i++)
		cin>>a[i];
	for(int i=1;i<=q;i++)
	{
		int op,x,y,z;
		cin>>op;
		if(op==1)
		{
			cin>>x>>y>>z;
			for(int j=x;j<=y;j++)
			{
				if(a[j]<=z)
				{
					a[j]+=z;
				}
			 } 
		}
		if(op==2)
		{
			cin>>x>>y;
			ans=0;
			for(int j=x;j<=y;j++)
			{
				ans=(ans%MOD+a[j]%MOD)%MOD;
			}
			cout<<ans<<endl;
		}
		if(op==3)
		{
			cin>>x>>y>>z;
			ans=0;
			for(int j=x;j<=y;j++)
			{
				if(a[j]<=z)
				{
					ans++;
				}
			}
			cout<<ans<<endl;
		} 
	}
	return 0;
}
