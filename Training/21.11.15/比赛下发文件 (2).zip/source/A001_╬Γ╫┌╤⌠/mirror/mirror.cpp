#include<iostream>
#include<cstdio>
#define INT __int128
#define MOD 67280421310721
using namespace std;
INT n,m,k;
INT x[110];
INT a[1000010];
INT p,q;
INT ans;
INT qread()
{
	INT x=0;
	char ch=getchar();
	while(ch<'0'||ch>'9')
		ch=getchar();
	while(ch>='0'&&ch<='9')
	{
		x*=10LL;
		x+=ch-'0';
		ch=getchar();
	}
	return x;
}
void write(INT x)
{
	if(x>9)
		write(x/10LL);
	putchar(x%10LL+'0');
}
void dfs(INT t)
{
	if(t==k+1)
	{
		INT res=0;
		for(INT i=1;i<=n;i++)
			res+=a[i]%MOD,res%=MOD;
		p+=res;
		p%=MOD;
		q++;
		return;
	}
	for(INT i=1;i<=n;i++)
	{
		a[i]^=x[t%m];
		dfs(t+1);
		a[i]^=x[t%m];
	}
}
INT power(INT a,INT b)
{
	INT res=1;
	while(b)
	{
		if(b&1)
			res*=a,res%=MOD;
		a*=a;
		a%=MOD;
		b>>=1;
	}
	return res;
}
INT gcd(INT a,INT b)
{
	if(a<b)
		swap(a,b);
	if(b==0)
		return a;
	return gcd(b,a%b);
}
int main()
{
	// #ifdef FIO
	// 	freopen("D:/Code/In.in","r",stdin);
	// 	freopen("D:/Code/Out.out","w",stdout);
	// #endif
	freopen("mirror.in","r",stdin);
	freopen("mirror.out","w",stdout);
	n=qread();
	m=qread();
	k=qread();
	for(INT i=0;i<m;i++)
		x[i]=qread();
	dfs(1);
	INT t=gcd(p,q);
	p/=t;
	q/=t;
	ans=power(q,MOD-2ll);
	ans*=p;
	ans%=MOD;
	write(ans);
	return 0;
}