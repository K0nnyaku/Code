#include<iostream>
#include<cstdio>
#include<cctype>
#include<cmath>
#define INT __int128
#define MOD 1000000007
using namespace std;
const INT MB=1<<20;
struct FastIO
{
	char ib[MB+100],*p,*q;
	char ob[MB+100],*r,stk[128];
	INT tp;
	FastIO(){p=q=ib,r=ob,tp=0;}
	~FastIO(){fwrite(ob,1,r-ob,stdout);}
	char read_char()
	{
		if(p==q)
		{
			p=ib,q=ib+fread(ib,1,MB,stdin);
			if(p==q)return 0;
		}
		return *p++;
	}
	template<typename T>
	void read_int(T& x)
	{
		char c=read_char(),l=0;
		for(x=0;!isdigit(c);c=read_char())l=c;
		for(;isdigit(c);c=read_char())x=x*10-'0'+c;
		if(l=='-')x=-x;
	}
	void write_char(char c)
	{
		if(r-ob==MB)r=ob,fwrite(ob,1,MB,stdout);
		*r++=c;
	}
	template<typename T>
	void write_int(T x) 
	{
		if(x<0)write_char('-'),x=-x;
		do stk[++tp]=x%10+'0';
		while(x/=10);
		while(tp)write_char(stk[tp--]);
	}
}IO;
INT n,q;
INT a[100010];
INT vis[100010];
INT minn[1010],len,tot;
INT f(INT a,INT b)
{
	if(a/b*b==a)
		return a/b;
	return a/b+1;
}
void push_up(INT p)
{
	vis[p]=(vis[p<<1]+vis[p<<1|1])%MOD;
}
void build(INT p,INT l,INT r)
{
	if(l==r)
	{
		vis[p]=a[l];
		return;
	}
	INT mid=(l+r)>>1;
	build(p<<1,l,mid);
	build(p<<1|1,mid+1,r);
	push_up(p);
}
void update(INT p,INT l,INT r,INT x,INT k)
{
	if(l==r)
	{
		vis[p]+=k;
		vis[p]%=MOD;
		return;
	}
	INT mid=(l+r)>>1;
	if(x<=mid)
		update(p<<1,l,mid,x,k);
	else
		update(p<<1|1,mid+1,r,x,k);
	push_up(p);
}
INT query(INT p,INT l,INT r,INT L,INT R)
{
	if(L<=l&&R>=r)
		return vis[p];
	INT mid=(l+r)>>1;
	INT res=0;
	if(L<=mid)
		res+=query(p<<1,l,mid,L,R),res%=MOD;
	if(R>=mid+1)
		res+=query(p<<1|1,mid+1,r,L,R);
	res%=MOD;
	return res;
}
int main()
{
	// #ifdef FIO
	// 	freopen("D:/Code/In.in","r",stdin);
	// 	freopen("D:/Code/Out.out","w",stdout);
	// #endif
	freopen("moon.in","r",stdin);
	freopen("moon.out","w",stdout);
	IO.read_int(n);
	IO.read_int(q);
	len=sqrt((double)n);
	tot=f(n,len);	
	for(INT i=1;i<=tot;i++)
		minn[i]=1e18;
	for(INT i=1;i<=n;i++)
		IO.read_int(a[i]);
	for(INT i=1;i<=n;i++)
		minn[f(i,len)]=min(minn[f(i,len)],a[i]);
	build(1,1,n);
	for(INT i=1;i<=q;i++)
	{
		INT op,l,r,x;
		IO.read_int(op);
		if(op==1)
		{
			IO.read_int(l);
			IO.read_int(r);
			IO.read_int(x);
			for(INT k=f(l,len);k<=f(r,len);k++)
				if(minn[k]<=x)
					for(INT j=max((k-1)*len+1,l);j<=min(k*len,r);j++)
						if(a[j]<=x)
						{
							a[j]+=x;
							update(1,1,n,j,x);
							if(a[j]>(INT)1e18)
								a[j]=1e18;
							minn[f(j,len)]=min(minn[f(j,len)],a[j]);
						}	
		}
		else if(op==2)
		{
			IO.read_int(l);
			IO.read_int(r);
			IO.write_int(query(1,1,n,l,r));
			IO.write_char('\n');
		}
		else
		{
			IO.read_int(l);
			IO.read_int(r);
			IO.read_int(x);
			INT res=0;
			for(INT k=f(l,len);k<=f(r,len);k++)
				if(minn[k]<=x)
					for(INT j=max((k-1)*len+1,l);j<=min(k*len,r);j++)
						if(a[j]<=x)
							res++;
			IO.write_int(res);
			IO.write_char('\n');
		}
	}
	return 0;
}