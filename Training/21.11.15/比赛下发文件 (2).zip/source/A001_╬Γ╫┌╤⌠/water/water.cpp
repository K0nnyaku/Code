#include<iostream>
#include<cstdio>
using namespace std;
int k,v; 
int main()
{
	freopen("water.in","r",stdin);
	freopen("water.out","w",stdout);
	scanf("%d%d",&k,&v);
	int n=2+k-1,m=2*k-1;
	printf("%d %d\n",n,m);
	printf("%d %d %d\n",1,n,v);
	for(int i=2;i<=k;i++)
	{
		printf("%d %d %d\n",1,i,1);
		printf("%d %d %d\n",i,n,v+i-2);
	}
	return 0;
}