#include<bits/stdc++.h>
#define ll long long
using namespace std;
const ll MOD=1e9+7;
ll n,q;
ll a[5010];
inline ll read() {
    char ch=getchar();ll x=0,f=1;
    while(ch<'0'||ch>'9'){if(ch=='-') f=-1;ch=getchar();} 
	while('0'<=ch&&ch<='9'){x=x*10+ch-'0';ch=getchar();} 
	return x*f;
}
int main(){
	freopen("moon.in","r",stdin);
	freopen("moon.out","w",stdout);
	n=read();q=read();
	for(ll i=1;i<=n;i++)
		a[i]=read();
	while(q--){
		ll op=read(),l=read(),r=read(),x,sum=0;
		if(op==1){
			x=read();
			for(ll i=1;i<=n;i++)
				if(a[i]<=x)
					a[i]+=x;
		}
		if(op==2){
			for(ll i=1;i<=n;i++)
				sum+=a[i],sum%=MOD;
			cout<<sum<<"\n";	
		}
		if(op==3){
			x=read();
			for(ll i=1;i<=n;i++)
				if(a[i]<=x)
					sum++;
			cout<<sum<<"\n";		
		}
		
	}
	return 0;
}
