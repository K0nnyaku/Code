#include<bits/stdc++.h>
#define ll long long
using namespace std;
const ll MOD=67280421310721;
ll n,m,k,sum,num,t;
ll a[110];
inline ll read() {
    char ch=getchar();ll x=0,f=1;
    while(ch<'0'||ch>'9'){if(ch=='-') f=-1;ch=getchar();} 
	while('0'<=ch&&ch<='9'){x=x*10+ch-'0';ch=getchar();} 
	return x*f;
}
void dfs(ll temp,ll v){
	if(temp>min(m,k)){
		sum=(sum+v)%MOD;
		num++;
		return;
	}
	dfs(temp+1,(v^a[temp%m])%MOD);
	dfs(temp+1,v);
}
int main(){
	freopen("mirror.in","r",stdin);
	freopen("mirror.out","w",stdout);
	n=read();m=read();k=read();
	for(ll i=0;i<m;i++)
		a[i]=read();
	dfs(1,0);
	t=(1<<(k%m))-1;
	if(k<=m)
		cout<<sum*n%MOD/num%MOD<<"\n";
	else
		cout<<sum*n%MOD/(num*t)%MOD<<"\n";
	return 0;
}
