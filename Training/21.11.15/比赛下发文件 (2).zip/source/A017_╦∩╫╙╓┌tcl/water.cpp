#include<bits/stdc++.h>
#define ll long long
using namespace std;
const ll MOD=67280421310721;
ll k,v;
inline ll read() {
    char ch=getchar();ll x=0,f=1;
    while(ch<'0'||ch>'9'){if(ch=='-') f=-1;ch=getchar();} 
	while('0'<=ch&&ch<='9'){x=x*10+ch-'0';ch=getchar();} 
	return x*f;
}
int main(){
	freopen("water.in","r",stdin);
	freopen("water.out","w",stdout);
	k=read();v=read();
	cout<<k+1<<" "<<2*k-1<<"\n";
	for(int i=2;i<k+1;i++)
		cout<<"1 "<<i<<" "<<k-1<<"\n";
	for(int i=2;i<k+1;i++)
		cout<<i<<" "<<k+1<<" "<<v<<"\n";
	cout<<"1 "<<k+1<<" "<<v<<"\n";
	return 0;
}
