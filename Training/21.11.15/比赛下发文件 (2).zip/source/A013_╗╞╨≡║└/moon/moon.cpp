#include<bits/stdc++.h>
#define ll long long
using namespace std;
const ll N=100010,MOD=1e9+7;
ll n,q,a[N],pos[N],remain[N];
ll op[N],l[N],r[N],x[N];
void sub1(ll l,ll r,ll x)
{
	for(ll i=l;i<=r;i++) if(a[i]<=x) a[i]+=x;
}
ll sub2(ll l,ll r)
{
	ll ans=0;
	for(ll i=l;i<=r;i++) ans=(ans+a[i])%MOD;
	return ans;
}
ll sub3(ll l,ll r,ll x)
{
	ll ans=0;
	for(ll i=l;i<=r;i++) ans+=(a[i]<=x);
	return ans;
}
signed main()
{
	clock_t c1=clock();
	freopen("moon.in","r",stdin);
	freopen("moon.out","w",stdout);

	//======================================
	scanf("%lld%lld",&n,&q); //ll siz=sqrt(n);
	for(ll i=1;i<=n;i++) scanf("%lld",&a[i]);//,pos[i]=(i-1)/siz;
//	ll tmp=pos[n],cnt=1;
//	for(ll i=n;i>=1;i--)
//	{
//		if(pos[i]==tmp) remain[i]=cnt,cnt++;
//		else cnt=1,tmp=pos[i],remain[i]=cnt;
//	}
	//mem//set(x,0x9f,sizeof(x));
	for(ll i=1;i<=q;i++)
	{
		scanf("%lld%lld%lld",&op[i],&l[i],&r[i]);
		if(op[i]==1 || op[i]==3) scanf("%lld",&x[i]);
	}
	for(ll i=1;i<=q;i++)
	{
		if(op[i]==1) sub1(l[i],r[i],x[i]);
		else if(op[i]==2) printf("%lld\n",sub2(l[i],r[i]));
		else printf("%lld\n",sub3(l[i],r[i],x[i]));
	}
	//======================================
	cerr<<endl<<"Time:"<<clock()-c1<<"(ms)"<<endl;
	return 0;
}
