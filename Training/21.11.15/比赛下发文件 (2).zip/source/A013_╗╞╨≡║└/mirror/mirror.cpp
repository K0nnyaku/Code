#include<bits/stdc++.h>
#define ll unsigned long long
using namespace std;
const ll N=1000010,MOD=67280421310721ull;
ll n,m,k,pro,a[N],x[N],random[N];
ll gcd(ll a,ll b) { return b?gcd(b,a%b):a; }
struct frac { ll p,q; frac(){p=0,q=1;} }ansans;
frac easy(frac qwq)
{
	ll g=gcd(qwq.p,qwq.q);
	qwq.p/=g;
	qwq.q/=g;
	return qwq;
}
frac operator * (frac a,frac b)
{
	frac ans;
	ll g=gcd(a.p,b.q);
	a.p/=g,b.q/=g;
	g=gcd(b.p,a.q);
	b.p/=g,a.q/=g;
	ans.p=a.p*b.p;
	ans.q=a.q*b.q;
//	if(ans.p<0 || ans.q<0) assert(0);
	return easy(ans);
}
frac operator + (frac a,frac b)
{
	frac ans;
	ll lcm=(a.q*b.q)/gcd(a.q,b.q);
	if(a.q*b.q<0) puts("!overflow!");
	a.p*=(lcm/a.q),b.p*=(lcm/b.q);
	ans.p=a.p+b.p;ans.q=lcm;	
	return easy(ans);
}
void dfs(ll layer)
{
	if(layer>k)
	{
//		printf("->>now a   :");for(ll i=1;i<=n;i++) printf("%lld ",a[i]);puts("");
//		printf("->>now rand:");for(ll i=1;i<=k;i++) printf("%lld ",random[i]);puts("");
		frac P,ans;
		P.p=1,P.q=pro,ans.q=1;
		for(ll i=1;i<=n;i++) ans.p+=a[i];
//		printf("probablity:%lld/%lld\n",P.p,P.q);
//		printf("SUM of arr:%lld\n",ans.p);
		P=P*ans;
//		printf("expection:%lld/%lld\n",P.p,P.q);
		ansans=ansans+P;
//		printf("now ans  =%lld/%lld\n",ansans.p,ansans.q);
		return;
	}
	for(ll i=1;i<=n;i++)
	{
		a[i]^=x[layer%m];
		random[layer]=i;
//		printf("now a:");for(ll j=1;j<=n;j++) printf("%lld ",a[j]);puts("");
		dfs(layer+1);
		a[i]^=x[layer%m];
	}
}
ll qpow(ll a,ll b)
{
	ll ans=1;
	while(b)
	{
		if(b&1) ans=ans*a%MOD;
		a=a*a%MOD;
		b>>=1;
	}
	return ans;	
}
ll inv(frac x)
{
	return x.p*qpow(x.q,MOD-2)%MOD;
}
signed main()
{
	clock_t c1=clock();
	freopen("mirror.in","r",stdin);
	freopen("mirror.out","w",stdout);

	//======================================
	scanf("%llu%llu%llu",&n,&m,&k);
	pro=1;
	for(ll i=1;i<=k;i++) pro*=n;
	for(ll i=0;i<m;i++) scanf("%llu",&x[i]);
	dfs(1);
	printf("%llu",inv(ansans));
	//======================================
	cerr<<endl<<"Time:"<<clock()-c1<<"(ms)"<<endl;
	return 0;
}
