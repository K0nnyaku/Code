#include<bits/stdc++.h>
using namespace std;
const int N=100010;
int k,v;
signed main()
{
	clock_t c1=clock();
	freopen("water.in","r",stdin);
	freopen("water.out","w",stdout);

	//======================================
	scanf("%d%d",&k,&v);
	int n=k+1,m=1+(k-1)*2;
	printf("%d %d\n",n,m);
	for(int i=2;i<n;i++) printf("%d %d %d\n",1,i,v+i-2);
	for(int i=2;i<n;i++) printf("%d %d %d\n",i,n,1);
	printf("%d %d %d",1,n,v);
	//======================================
	cerr<<endl<<"Time:"<<clock()-c1<<"(ms)"<<endl;
	return 0;
}
