#include<iostream>
int main() { freopen("flower.in","r",stdin);
freopen("flower.out","w",stdout);
return printf("0 0"),0; }

/**********************************

      Techmino HaoWan!!!!
    Play on home.techmino.org
  Explore interesting MINO techs!
  
             00   
              0     0
           00 0000000
           0  0000000
           0   000000
           00 0000000
           00 0000000

**********************************/