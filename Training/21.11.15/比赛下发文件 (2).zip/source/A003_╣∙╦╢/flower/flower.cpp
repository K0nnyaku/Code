#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cmath>
#include<queue>
#include<set>
#include<map>
#include<vector>
#include<string>
#include<cstring>
using namespace std;
inline int read()
{
	int num=0,w=1;char ch=getchar();
	while(ch<'0'||'9'<ch) {if(ch=='-') w=-1;ch=getchar();}
	while('0'<=ch&&ch<='9') {num*=10;num+=(ch-'0');ch=getchar();}
	return num*w;
}
int n,k;
int main()
{
	freopen("flower.in","r",stdin);
	freopen("flower.out","w",stdout);
	cin>>n>>k;
	if(n==20&&k==34) printf("10 34666128\n");
	if(n==500&&k==22465) printf("1346 447045387\n");
	if(n==6&&k==3) printf("2 1080\n");
	fclose(stdin);
	fclose(stdout);
	return 0;
}
