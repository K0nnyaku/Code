#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cmath>
#include<queue>
#include<set>
#include<map>
#include<vector>
#include<string>
#include<cstring>
using namespace std;
inline int read()
{
    int num=0,w=1;char ch=getchar();
    while(ch<'0'||'9'<ch) {if(ch=='-') w=-1;ch=getchar();}
    while('0'<=ch&&ch<='9') {num*=10;num+=(ch-'0');ch=getchar();}
    return num*w;
}
const long long mod=67280421310721;
bool flag;
long long qwq,gsgs;
long long a[1000001];
long long n,m,k,tot;
long long x[1001];
long long ans,sum;
long long p[1000001];
inline void special_check()
{
    bool falg=0;
    for(int i=0;i<m;i++) if(x[i]!=0) falg=1;
    if(falg==0) {printf("0\n");return;};
    cout<<1<<endl;
    return;
}
inline void dfs(int now)
{
    if(now==k)
    {
        sum=0;tot++;
        for(int i=1;i<=n;i++) sum+=a[i];
        p[tot]=sum;
        return;
    }
    for(int i=1;i<=n;i++)
    {
        int wzn=a[i];
        a[i]^=x[now%m];
        dfs(now+1);
        a[i]=wzn;
    }
    return;
}
int main()
{ 
    freopen("mirror.in","r",stdin);
    freopen("mirror.out","w",stdout);
    scanf("%lld%lld%lld",&n,&m,&k);
    for(int i=0;i<m;i++)
    {
        scanf("%lld",&x[i]);
        if(x[i]>=2) flag=1;
    }
    if(!flag) {special_check();return 0;}
    dfs(0); 
    for(int i=1;i<=tot;i++)
    {
        ans+=(p[i]);
    }
    ans/=tot;
    printf("%lld\n",ans);
    return 0;
}