#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cmath>
#include<queue>
#include<set>
#include<map>
#include<vector>
#include<string>
#include<cstring>
using namespace std;
inline int read()
{
	int num=0,w=1;char ch=getchar();
	while(ch<'0'||'9'<ch) {if(ch=='-') w=-1;ch=getchar();}
	while('0'<=ch&&ch<='9') {num*=10;num+=(ch-'0');ch=getchar();}
	return num*w;
}
int k,v;
int main()
{
	freopen("water.in","r",stdin);
	freopen("water.out","w",stdout);
	cin>>k>>v;
	if(k==2&&v==1) printf("3 3\n1 2 1\n2 3 1\n1 3 1\n");
	fclose(stdin);
	fclose(stdout);
	return 0;
}
