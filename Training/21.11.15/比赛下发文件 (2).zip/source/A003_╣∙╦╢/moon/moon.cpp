#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cmath>
#include<queue>
#include<set>
#include<map>
#include<vector>
#include<string>
#include<cstring>
using namespace std;
inline int read()
{
    int num=0,w=1;char ch=getchar();
    while(ch<'0'||'9'<ch) {if(ch=='-') w=-1;ch=getchar();}
    while('0'<=ch&&ch<='9') {num*=10;num+=(ch-'0');ch=getchar();}
    return num*w;
}
const long long mod=1e9+7;
int n,q,ans;
long long x,qwq;
long long a[1000001];
long long sum[1000001];
int op,l,r;
int main()
{
    freopen("moon.in","r",stdin);
    freopen("moon.out","w",stdout);
	scanf("%d%d",&n,&q);
    for(int i=1;i<=n;i++) scanf("%lld",&a[i]),sum[i]=sum[i-1]+a[i];
    while(q--)
    {
        scanf("%d%d%d",&op,&l,&r);
        if(op==1)
        {
            qwq=0;
            scanf("%lld",&x);
            for(int i=l;i<=r;i++)
                if(a[i]<=x) 
                {
                    a[i]+=x;
                    qwq+=x;
                    sum[i]+=qwq;
                }
            for(int i=r+1;i<=n;i++) sum[i]+=qwq;
        }
        else if(op==2){printf("%lld\n",(sum[r]-sum[l-1])%mod);}
        else if(op==3)
        {
            scanf("%lld",&x);
            ans=0;
            for(int i=l;i<=r;i++) if(a[i]<=x) ans++;
            printf("%d\n",ans);
        }
    }
    return 0;
}
