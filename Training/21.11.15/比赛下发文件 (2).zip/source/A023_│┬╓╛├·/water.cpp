#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
#include <ctime>
using namespace std;
int k, v;

int main()
{
#ifdef FIO
    freopen("D:/Code/In.in", "r", stdin);
    freopen("D:/Code/Out.out", "w", stdout);
#else
    freopen("water.in", "r", stdin);
    freopen("water.out", "w", stdout);
#endif
    int Times = clock();
    scanf("%d%d", &k, &v);
    int n = k + 1, m = 2 * k - 1;
    printf("%d %d\n", n, m);
    printf("%d %d %d\n", 1, n, v);
    for (int i = 2; i <= k; i ++)
    {
        printf("%d %d %d\n", 1, i, i - 1);
        printf("%d %d %d\n", i, n, v);
    }

    cerr << "Time : " << clock() - Times << " (ms)\n";
    return 0;
}