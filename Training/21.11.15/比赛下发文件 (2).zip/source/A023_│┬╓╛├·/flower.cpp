#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
#include <ctime>
using namespace std;
typedef long long ll;
const int N = 1e5 + 10, M = 2 * N;
const ll mod = 998244353;
int n, m, a[N];
int h[N], e[M], ne[M], tot = 0;
int depth[N], fa[N][21];
int temp[N], idx = 0, ans1 = 0;
ll ans2 = 1;
bool st[N];

void add(int a, int b)
{
    e[++ tot] = b, ne[tot] = h[a], h[a] = tot;
}

void dfs(int u, int father)
{
    for (int i = h[u]; i != -1; i = ne[i])
    {
        int j = e[i];
        if(j == father) continue;
        depth[j] = depth[u] + 1;
        fa[j][0] = u;
        for (int k = 1; k <= 20; k ++)
            fa[j][k] = fa[fa[j][k - 1]][k - 1];
        dfs(j, u);
    }
}

int lca(int a, int b)
{
    if(depth[a] < depth[b]) swap(a, b);
    for (int k = 20; k >= 0; k --)
        if(depth[fa[a][k]] >= depth[b]) a = fa[a][k];
    if(a == b) return a;

    for (int k = 20; k >= 0; k --)
        if(fa[a][k] != fa[b][k]) a = fa[a][k], b = fa[b][k];
    return fa[a][0];
}

int get()
{
    memset(st, 0, sizeof st);
    int cnt = 0;
    for (int i = 1; i <= idx; i ++) cnt += depth[temp[i]];
    for (int i = 1; i <= idx; i ++)
    for (int j = i + 1; j <= idx; j ++)
    {
        int t = lca(temp[i], temp[j]);
        if (!st[t])
        {
            st[t] = true;
            cnt += depth[t];
        }
    }
    return cnt;
}

void DFS(int u)
{
    if(u == m + 1)
    {
        if(idx == 0) return ;
        int t = get();
        ans1 ^= t;
        ans2 = ans2 * (ll)t % mod;
        return ;
    }

    DFS(u + 1);
    temp[++ idx] = a[u];
    DFS(u + 1);
    idx --;
}

int main()
{
#ifdef FIO
    freopen("D:/Code/In.in", "r", stdin);
    freopen("D:/Code/Out.out", "w", stdout);
#else
    freopen("flower.in", "r", stdin);
    freopen("flower.out", "w", stdout);
#endif
    int Times = clock();

    memset(h, -1, sizeof h);
    scanf("%d%d", &n, &m);
    for (int i = 1; i <= m; i ++) scanf("%d", &a[i]);
    for (int i = 1; i < n; i ++)
    {
        int a, b;
        scanf("%d%d", &a, &b);
        add(a, b), add(b, a);
    }
    depth[0] = -1;
    dfs(1, -1);
    DFS(1);
    printf("%d %lld\n", ans1, ans2);
    cerr << "Time : " << clock() - Times << " (ms)\n";
    return 0;
}