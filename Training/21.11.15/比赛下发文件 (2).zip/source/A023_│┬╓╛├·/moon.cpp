#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
#include <ctime>
using namespace std;
typedef long long ll;
const int N = 1e5 + 10;
const ll mod = 1e9 + 7;
int n, q;
ll a[N], sum[N];

struct FastIN
{
    char buf[(1 << 21) + 100], *p, *e;
    int getChar()
    {
        if (p == e) p = buf, e = buf + fread(buf, 1, (1 << 21), stdin);
        return p == e ? EOF : *p++;
    }
    template<typename T>
    FastIN& operator>>(T& x)
    {
        char c, l;
        for (c = 0; !isdigit(c); c = getChar()) l = c;
        for (x = 0; isdigit(c); c = getChar()) x = x * 10 - '0' + c;
        if (l == '-') x = -x;
        return *this;
    }
} IN;

int main()
{
#ifdef FIO
    freopen("D:/Code/In.in", "r", stdin);
    freopen("D:/Code/Out.out", "w", stdout);
#else
    freopen("moon.in", "r", stdin);
    freopen("moon.out", "w", stdout);
#endif
    int Times = clock();

    scanf("%d%d", &n, &q);
    for (int i = 1; i <= n; i ++) scanf("%lld", &a[i]);
    if(n <= 5000 && q <= 5000)
    {
        while (q --)
        {
            int op;
            IN >> op;
            if (op == 1)
            {
                int l, r;
                ll x;
                IN >> l >> r >> x;
                for (int i = l; i <= r; i ++)
                    if(a[i] <= x) a[i] = (a[i] + x);
            }
            else if (op == 2)
            {
                int l, r;
                IN >> l >> r;
                ll res = 0;
                for (int i = l; i <= r; i ++) res = (res + a[i]) % mod;
                printf("%lld\n", res);
            }
            else 
            {
                int l, r;
                ll x;
                IN >> l >> r >> x;
                int res = 0;
                for (int i = l; i <= r; i ++) 
                    if (a[i] <= x) res ++;
                printf("%d\n", res);
            }
        }
    }
    else 
    {
        for (int i = 1; i <= n; i ++) sum[i] = (sum[i - 1] + a[i]) % mod;
        while (q --)
        {
            int op;
            IN >> op;
            if (op == 1)
            {
                int l, r;
                ll x;
                IN >> l >> r >> x;
                for (int i = l; i <= r; i ++)
                    if(a[i] <= x) a[i] = (a[i] + x);
            }
            else if (op == 2)
            {
                int l, r;
                IN >> l >> r;
                printf("%lld\n", (sum[r] - sum[l - 1] + mod ) % mod);
            }
            else 
            {
                int l, r;
                ll x;
                IN >> l >> r >> x;
                int res = 0;
                for (int i = l; i <= r; i ++) 
                    if (a[i] <= x) res ++;
                printf("%d\n", res);
            }
        }
        return 0;
    }

    cerr << "Time : " << clock() - Times << " (ms)\n";
    return 0;
}