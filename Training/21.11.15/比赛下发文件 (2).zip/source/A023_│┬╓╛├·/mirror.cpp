#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
#include <ctime>
using namespace std;
typedef long long ll;
const int N = 1e6 + 10;
const ll mod = 67280421310721;
int n, m, k;
ll x[N], temp[N], cnt = 0, ans = 0;

ll mul(ll a, ll b)
{
    ll res = 0;
    while(b)
    {
        if (b & 1) res = (res + a) % mod;
        a = a * 2 % mod;
        b >>= 1;
    }
    return res;
}

ll qmi(ll x, ll k)
{
    ll res = 1;
    while (k)
    {
        if (k & 1) res = mul(res, x) % mod;
        x = mul(x, x) % mod;
        k >>= 1;
    }
    return res;
}

void dfs(int u)
{
    if (u == k)
    {
        ll sum = 0;
        for (int i = 1; i <= n; i ++)
            sum = (sum + temp[i]) % mod;
        ans += sum;
        cnt ++;
        return ;
    }

    for (int i = 1; i <= n; i ++)
    {
        temp[i] ^= x[u % m];
        dfs(u + 1);
        temp[i] ^= x[u % m];
    }
}

int main()
{
#ifdef FIO
    freopen("D:/Code/In.in", "r", stdin);
    freopen("D:/Code/Out.out", "w", stdout);
#else
    freopen("mirror.in", "r", stdin);
    freopen("mirror.out", "w", stdout);
#endif
    int Times = clock();
    scanf("%d%d%d", &n, &m, &k);
    for (int i = 0; i < m; i ++) scanf("%lld", &x[i]);
    dfs(0);
    printf("%lld\n", mul(ans, qmi(cnt, mod - 2)));
    cerr << "Time : " << clock() - Times << " (ms)\n";
    return 0;
}