#include<iostream>
#include<cstdio>
using namespace std;
int main()
{
	freopen("flower.in","r",stdin);
	freopen("flower.out","w",stdout);
	cout<<1<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
