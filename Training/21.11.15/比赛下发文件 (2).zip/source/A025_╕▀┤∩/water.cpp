#include<iostream>
#include<cstdio>
using namespace std;
int k,v;
int main()
{
	freopen("water.in","r",stdin);
	freopen("water.out","w",stdout);
	scanf("%d%d",&k,&v);
//	if(k==1){
//		cout<<2<<' '<<1<<endl;
//		cout<<1<<' '<<2<<' '<<1<<endl;
//	}
//	if(k==2){
//		cout<<3<<' '<<3<<endl;
//		cout<<1<<' '<<2<<' '<<1<<endl;
//		cout<<2<<' '<<3<<' '<<k+v-2<<endl;
//		cout<<1<<' '<<3<<' '<<v<<endl;
//	}
//	if(k==3){
//		cout<<4<<' '<<4<<endl;
//		cout<<1<<' '<<2<<' '<<1<<endl;
//		cout<<2<<' '<<3<<' '<<k+v-2<<endl;
//		cout<<2<<' '<<4<<' '<<k+v-3<<endl;
//		cout<<1<<' '<<4<<' '<<v<<endl;
//	}
//	if(k==4){
//		cout<<5<<' '<<7<<endl;
//		cout<<1<<' '<<2<<' '<<1<<endl;
//		cout<<1<<' '<<4<<' '<<k+v-4<<endl;
//		cout<<1<<' '<<3<<' '<<k+v-3<<endl;
//		cout<<2<<' '<<5<<' '<<k+v-2<<endl;
//		cout<<4<<' '<<5<<' '<<1<<endl;
//		cout<<3<<' '<<5<<' '<<1<<endl;
//		cout<<1<<' '<<5<<' '<<v<<endl;
//	}
//	if(k==5){
//		cout<<6<<' '<<9<<endl;
//		cout<<1<<' '<<2<<' '<<1<<endl;
//		cout<<2<<' '<<6<<' '<<k+v-2<<endl;
//		cout<<1<<' '<<3<<' '<<k+v-3<<endl;
//		cout<<3<<' '<<6<<' '<<1<<endl;
//		cout<<1<<' '<<4<<' '<<k+v-4<<endl;
//		cout<<4<<' '<<6<<' '<<1<<endl;
//		cout<<1<<' '<<5<<' '<<v+k-5<<endl;
//		cout<<5<<' '<<6<<' '<<1<<endl;
//		cout<<1<<' '<<6<<' '<<v<<endl;
//	}
//	if(k==6){
//		cout<<7<<' '<<11<<endl;
//		cout<<1<<' '<<2<<' '<<1<<endl;
//		cout<<2<<' '<<7<<' '<<k+v-2<<endl;
//		cout<<1<<' '<<3<<' '<<k+v-3<<endl;
//		cout<<3<<' '<<7<<' '<<1<<endl;
//		cout<<1<<' '<<4<<' '<<k+v-4<<endl;
//		cout<<4<<' '<<7<<' '<<1<<endl;
//		cout<<1<<' '<<5<<' '<<v+k-5<<endl;
//		cout<<5<<' '<<7<<' '<<1<<endl;
//		cout<<1<<' '<<6<<' '<<v+k-6<<endl;
//		cout<<6<<' '<<7<<' '<<1<<endl;
//		cout<<1<<' '<<7<<' '<<v<<endl;
//	}
//	if(k==7){
//		cout<<8<<' '<<13<<endl;
//		cout<<1<<' '<<2<<' '<<1<<endl;
//		cout<<2<<' '<<8<<' '<<k+v-2<<endl;
//		cout<<1<<' '<<3<<' '<<k+v-3<<endl;
//		cout<<3<<' '<<8<<' '<<1<<endl;
//		cout<<1<<' '<<4<<' '<<k+v-4<<endl;
//		cout<<4<<' '<<8<<' '<<1<<endl;
//		cout<<1<<' '<<5<<' '<<v+k-5<<endl;
//		cout<<5<<' '<<8<<' '<<1<<endl;
//		cout<<1<<' '<<6<<' '<<v+k-6<<endl;
//		cout<<6<<' '<<8<<' '<<1<<endl;
//		cout<<1<<' '<<7<<' '<<v+k-7<<endl;
//		cout<<7<<' '<<8<<' '<<1<<endl;
//		cout<<1<<' '<<8<<' '<<v<<endl;
//	}// 6 10
//	if(k==8){
//		cout<<9<<' '<<15<<endl;
//		cout<<1<<' '<<2<<' '<<1<<endl;
//		cout<<2<<' '<<9<<' '<<k+v-2<<endl;
//		cout<<1<<' '<<3<<' '<<k+v-3<<endl;
//		cout<<3<<' '<<9<<' '<<1<<endl;
//		cout<<1<<' '<<4<<' '<<k+v-4<<endl;
//		cout<<4<<' '<<9<<' '<<1<<endl;
//		cout<<1<<' '<<5<<' '<<v+k-5<<endl;
//		cout<<5<<' '<<9<<' '<<1<<endl;
//		cout<<1<<' '<<6<<' '<<v+k-6<<endl;
//		cout<<6<<' '<<9<<' '<<1<<endl;
//		cout<<1<<' '<<7<<' '<<v+k-7<<endl;
//		cout<<7<<' '<<9<<' '<<1<<endl;
//		cout<<1<<' '<<8<<' '<<v+k-8<<endl;
//		cout<<8<<' '<<9<<' '<<1<<endl;
//		cout<<1<<' '<<9<<' '<<v<<endl;
//	}
//	if(k==9){
//		cout<<10<<' '<<17<<endl;
//		cout<<1<<' '<<2<<' '<<1<<endl;
//		cout<<2<<' '<<10<<' '<<k+v-2<<endl;
//		cout<<1<<' '<<3<<' '<<k+v-3<<endl;
//		cout<<3<<' '<<10<<' '<<1<<endl;
//		cout<<1<<' '<<4<<' '<<k+v-4<<endl;
//		cout<<4<<' '<<10<<' '<<1<<endl;
//		cout<<1<<' '<<5<<' '<<v+k-5<<endl;
//		cout<<5<<' '<<10<<' '<<1<<endl;
//		cout<<1<<' '<<6<<' '<<v+k-6<<endl;
//		cout<<6<<' '<<10<<' '<<1<<endl;
//		cout<<1<<' '<<7<<' '<<v+k-7<<endl;
//		cout<<7<<' '<<10<<' '<<1<<endl;
//		cout<<1<<' '<<8<<' '<<v+k-8<<endl;
//		cout<<8<<' '<<10<<' '<<1<<endl;
//		cout<<1<<' '<<9<<' '<<v+k-9<<endl;
//		cout<<9<<' '<<10<<' '<<1<<endl;
//		cout<<1<<' '<<10<<' '<<v<<endl;
//	}
//	if(k==10){
//		cout<<11<<' '<<19<<endl;
//		cout<<1<<' '<<2<<' '<<1<<endl;
//		cout<<2<<' '<<11<<' '<<k+v-2<<endl;
//		cout<<1<<' '<<3<<' '<<k+v-3<<endl;
//		cout<<3<<' '<<11<<' '<<1<<endl;
//		cout<<1<<' '<<4<<' '<<k+v-4<<endl;
//		cout<<4<<' '<<11<<' '<<1<<endl;
//		cout<<1<<' '<<5<<' '<<v+k-5<<endl;
//		cout<<5<<' '<<11<<' '<<1<<endl;
//		cout<<1<<' '<<6<<' '<<v+k-6<<endl;
//		cout<<6<<' '<<11<<' '<<1<<endl;
//		cout<<1<<' '<<7<<' '<<v+k-7<<endl;
//		cout<<7<<' '<<11<<' '<<1<<endl;
//		cout<<1<<' '<<8<<' '<<v+k-8<<endl;
//		cout<<8<<' '<<11<<' '<<1<<endl;
//		cout<<1<<' '<<9<<' '<<v+k-9<<endl;
//		cout<<9<<' '<<11<<' '<<1<<endl;
//		cout<<1<<' '<<10<<' '<<v+k-10<<endl;
//		cout<<10<<' '<<11<<' '<<1<<endl;
//		cout<<1<<' '<<11<<' '<<v<<endl;
//	}
	if(k>=1){
		cout<<k+1<<' '<<k+(k-1)<<endl;
		for(int i=2;i<=k;i++){
			cout<<1<<' '<<i<<' '<<1<<endl;
			cout<<i<<' '<<k+1<<' '<<k+v-i<<endl;
		}
		cout<<1<<' '<<k+1<<' '<<v<<endl;
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
