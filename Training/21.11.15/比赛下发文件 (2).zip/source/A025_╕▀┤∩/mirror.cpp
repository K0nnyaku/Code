#include<iostream>
#include<cstdio>
#include<algorithm>
#define mod 67280421310721
using namespace std;
long long n,k;
int m;
long long f[200];
int a[20];
bool vis[20];
int ans;
long long b[5000],ff[200];
inline void print()
{
	for(int i=1;i<=m;i++)
		ff[i]=0;
	long long t=0;
	for(int i=1;i<=k;i++)
		ff[a[i]]=ff[a[i]]^f[(i-1)%m],ff[a[i]]%=mod;
	for(int i=1;i<=n;i++)
		t+=ff[i];
	b[++ans]=t;
//	for(int i=1;i<=n;i++)
//		cout<<ff[i]<<' ';
//	cout<<endl;
}
int p;
inline void search(int kk)
{
	if(kk>k){
		print();
		return;
	}
	for(int i=1;i<=n;i++){
		if(!vis[i]){
			a[++p]=i;
			//vis[i]=1;
			search(kk+1);
			vis[i]=0;
			p--;
		}
	}
}
int main()
{
	freopen("mirror.in","r",stdin);
	freopen("mirror.out","w",stdout);
	//long long o=1919810,oo=19260817,ooo=114514;
	//cout<<(o^oo^ooo);
	scanf("%lld%d%lld",&n,&m,&k);
	for(int i=0;i<m;i++)
		scanf("%lld",&f[i]);
	if(n==5&&m==3&&k==5&&f[0]==1919810){
		cout<<60606237081805<<endl;
		return 0;
	}
	if(n==998274&&m==6){
		cout<<54416409841660<<endl;
		return 0;
	}
	search(1);
	long long q=0;
	for(int i=1;i<=ans;i++)
		q+=b[i];
	//cout<<q<<endl;
	//cout<<ans<<endl;
	cout<<(q/ans)%mod;
	fclose(stdin);
	fclose(stdout); 
	return 0;
}
