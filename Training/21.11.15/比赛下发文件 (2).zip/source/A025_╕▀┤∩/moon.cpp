#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
#define mod 1000000007
#define MAXN 100010
using namespace std;
inline long long read()
{
	long long s=0,w=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-') w=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		s=s*10+ch-'0';
		ch=getchar();
	}
	return s*w;
}
long long n,q;
unsigned long long f[5010];
long long op;
long long l,r,x;
inline void work()
{
	for(int i=1;i<=n;i++)
		cin>>f[i];
	while(q--){
		op=read();
		if(op==1){
			l=read(),r=read(),x=read();
			for(int i=l;i<=r;i++)
				if(f[i]<=x) f[i]=f[i]+x;
		}
		if(op==2){
			unsigned long long ans=0;
			l=read(),r=read();
			for(int i=l;i<=r;i++)
				ans=(ans+f[i])%mod;
			cout<<ans<<endl;
		}
		if(op==3){
			long long ans=0;
			l=read(),r=read(),x=read();
			for(int i=l;i<=r;i++)
				if(f[i]<=x) ans++;
			printf("%lld\n",ans);
		}
	}
}
long long a[MAXN],sum[MAXN];
int main()
{
	freopen("moon.in","r",stdin);
	freopen("moon.out","w",stdout);
	n=read(),q=read();
	if(n<=5000&&q<=5000){
		work();
		return 0;
	}
	for(int i=1;i<=n;i++)
		f[i]=read(),sum[i]=(sum[i-1]+f[i])%mod;
	while(q--){
		op=read();
		if(op==1){
			l=read(),r=read(),x=read();
			for(int i=l;i<=r;i++)
				if(f[i]<=x) f[i]=f[i]+x;
		}
		if(op==2){
			l=read(),r=read();
			cout<<(sum[r]-sum[l-1])%mod<<endl;
		}
		if(op==3){
			long long ans=0;
			l=read(),r=read(),x=read();
			for(int i=l;i<=r;i++)
				if(f[i]<=x) ans++;
			printf("%lld\n",ans);
		}
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
