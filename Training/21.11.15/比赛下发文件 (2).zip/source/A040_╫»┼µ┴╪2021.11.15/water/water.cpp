#include<iostream>
using namespace std;
int k,v;
int n,m;
int tot=0;
struct edge{
	int u,v,ne,w;
}e[10000];
void add(int x,int y,int z)
{
	tot++;
	e[tot].u=x;
	e[tot].v=y;
	e[tot].w=z;
}
int main()
{
	freopen("water.in","r",stdin);
	freopen("water.out","w",stdout); 
	cin>>k>>v;
	n=k+1;
	m=(k-1)*2+1;
	add(1,n,v); 
	for(int i=2;i<n-1;i++)
	{
		add(1,i,1);
		add(i,n,v); 
	}
	if(k+v-1>v+1)
	{
		add(1,n-1,v);
		add(n-1,n,k+v-1-v);
	}
	else 
	{
		add(1,n-1,1);
		add(n-1,n,v); 
	}
	cout<<n<<" "<<m<<endl;
	for(int i=1;i<=tot;i++)
		cout<<e[i].u<<" "<<e[i].v<<" "<<e[i].w<<endl;
	return 0;
}
