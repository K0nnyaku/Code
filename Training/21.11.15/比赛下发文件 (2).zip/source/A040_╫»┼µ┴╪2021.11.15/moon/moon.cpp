#include<iostream>
#define int unsigned long long  
using namespace std;
const int mod=1e9+7;
int n,q;
int sum[600000];
int a[600000];
signed main()
{
	freopen("moon.in","r",stdin);
	freopen("moon.out","w",stdout);
	cin>>n>>q;
	for(int i=1;i<=n;i++)
	{
		cin>>a[i];
		sum[i]=sum[i-1]+a[i];
	} 
	while(q--)
	{
		int x,y,z;
		int op;
		cin>>op;
		if(op==1)
		{
			cin>>x>>y>>z;
			for(int i=x;i<=y;i++)
			{
				if(a[i]<=z)
				{
					a[i]+=z;
				}
			}
			for(int i=x;i<=n;i++)
			{
				sum[i]=sum[i-1]+a[i];
			}
		}
		if(op==2)
		{
			cin>>x>>y;
			cout<<(sum[y]-sum[x-1])%mod<<endl;
		}
		if(op==3)
		{
			int ans=0;
			cin>>x>>y>>z;
			for(int i=x;i<=y;i++)
			{
				if(a[i]<=z)
				{
					ans++;
				}
			}
			cout<<ans<<endl;
		}
	}
	return 0;
}
