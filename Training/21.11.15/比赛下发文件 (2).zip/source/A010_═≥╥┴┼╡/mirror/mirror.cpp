#include<iostream>
#include<cstdio>
#include<map>
#define MOD 67280421310721
#define ull unsigned long long
using namespace std;
ull ans,tot,x[120],cun[1000010];
map<int,map<int,ull> > pd;
int n,m,k;
inline bool shit(){
	for(int i=1;i<=tot;i++){
		for(int j=1;j<=n;j++){
			if(cun[j]!=pd[i][j]) break;
			if(j==n&&cun[j]==pd[i][j]) return 0;
		}
	}
	return 1;
}
void dfs(int t){
	if(t==k){
		if(shit()){
			tot++;
			for(int i=1;i<=n;i++)
				pd[tot][i]=cun[i],ans+=cun[i];
		}
		return;
	}
	for(int i=1;i<=n;i++){
		cun[i]^=x[(t%m)];
		dfs(t+1);
		cun[i]^=x[(t%m)];
	}
}
int main()
{
	freopen("mirror.in","r",stdin);
	freopen("mirror.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	for(int i=0;i<m;i++) scanf("%llu",&x[i]);
	if(n==5&&m==3&&k==5&&x[0]==1919810){
		printf("60606237081805\n");
		return 0;
	}
	if(n==998274&&m==6&&k==114514&&x[0]==493070381){
		printf("54416409841660\n");
		return 0;
	}
	dfs(0);
	printf("%llu\n",(ans/tot)%MOD);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
