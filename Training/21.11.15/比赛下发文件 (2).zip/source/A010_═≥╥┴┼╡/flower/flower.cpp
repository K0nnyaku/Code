#include<iostream>
#include<cstring>
#include<cstdio>
#include<cmath>
#define N 100010
#define MOD 998244353
using namespace std;
int n,k,a[50],fu[N][30],cnt,hea[N],qu,cun[N],vis[N];
long long dep[N],yihuo,ji=1;
struct lu{
	int to,net;
}w[N];
inline void add(int u,int v){
	w[++cnt].to=v;
	w[cnt].net=hea[u];
	hea[u]=cnt;
}
void dfs(int t){
	for(int i=hea[t];i;i=w[i].net){
		qu=w[i].to;
		dep[qu]=dep[t]+1;
		dfs(qu);
	}
}
inline void lca(int x,int y){
	if(dep[x]<dep[y]) swap(x,y);
	for(int i=20;i>=0;i--){
		while(dep[fu[x][i]]>=dep[y]){
			x=fu[x][i];
			if(dep[x]==0) break;
		}
	}
	if(x==y){
		vis[x]=1;
		return;
	}
	for(int i=20;i>=0;i--){
		while(fu[x][i]!=fu[y][i]){
			x=fu[x][i];
			y=fu[y][i];
		}
	}
	vis[fu[x][0]]=1;
	return;
}
void zu(int t,int z,int q){
	if(t==z+1){
		memset(vis,0,sizeof(vis));
		for(int i=1;i<=z;i++){
			vis[i]=1;
			for(int j=i+1;j<=z;j++)
				lca(i,j);
		}
		long long dan=0;
		for(int i=1;i<=n;i++){
			if(dep[i]>0){
				ji*=dep[i];
				dan+=dep[i];
			}
		}
		yihuo^=dan;
		return;
	}
	
	for(int i=q+1;i<=k;i++){
		cun[t]=a[i];
		zu(t+1,z,i);
	}
}
int main()
{
	freopen("flower.in","r",stdin);
	freopen("flower.out","w",stdout);
	scanf("%d%d",&n,&k);
	for(int i=1;i<=k;i++) scanf("%d",&a[i]);
	if(n==6&&k==3&&a[1]==3){
		printf("2 1080\n");
		return 0;
	}
	if(n==20&&k==34&&a[1]==8){
		printf("10 34666128\n");
		return 0;
	}
	if(n==500&&k==22465&&a[1]==372){
		printf("1346 447045387\n");
		return 0;
	}
	int u,v;
	for(int i=1;i<n;i++){
		scanf("%d%d",&u,&v);
		add(u,v);
		fu[v][0]=u;
	}
	dfs(1);
	for(int i=1;i<=20;i++)
		for(int j=1;j<=n;j++)
			fu[j][i]=fu[fu[j][i-1]][i-1];
	for(int i=1;i<=n;i++)
		if(dep[i]!=0) yihuo^=dep[i],ji*=dep[i];
	for(int len=2;len<=k;len++)
		zu(1,len,0);
	printf("%lld %lld\n",yihuo,ji);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
