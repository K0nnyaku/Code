#include<iostream>
#include<cstdio>
using namespace std;
int main()
{
	freopen("water.in","r",stdin);
	freopen("water.out","w",stdout);
	int a,b,c;
	cin>>a>>b;
	if(a==2&&b==1){
		printf("3 3\n1 2 1\n2 3 1\n1 3 1\n");
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
