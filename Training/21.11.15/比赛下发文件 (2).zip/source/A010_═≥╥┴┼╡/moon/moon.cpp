#include<iostream>
#include<cstring>
#include<cstdio>
#define N 100010
#define ull unsigned long long
#define MOD 1000000007
#define tl t<<1
#define tr t<<1|1
using namespace std;
struct tree{
	int l,r;
	ull sum,maxn,minn,lazy;
}a[N*4];
int n,q,s,t,f;
ull k,c[N];
inline ull readu(){
	ull o=0;
	char ch=getchar();
	if(ch>'9'||ch<'0') ch=getchar();
	while(ch>='0'&&ch<='9') o=o*10+ch-'0',ch=getchar();
	return o;
}
inline int readd(){
	int o=0;
	char ch=getchar();
	if(ch>'9'||ch<'0') ch=getchar();
	while(ch>='0'&&ch<='9') o=o*10+ch-'0',ch=getchar();
	return o;
}
inline void push_up(int t){
	a[t].sum=a[tl].sum+a[tr].sum;
	a[t].sum%=MOD; 
	a[t].minn=min(a[tl].minn,a[tr].minn);
	a[t].maxn=max(a[tl].maxn,a[tr].maxn);
	return;
}
void build(int t,int l,int r){
	a[t].l=l;
	a[t].r=r;
	if(l==r){
		a[t].maxn=a[t].minn=a[t].sum=c[l];
		a[t].sum%=MOD;
		return;
	}
	int mid=(l+r)>>1;
	build(tl,l,mid);
	build(tr,mid+1,r);
	push_up(t);
}
inline void push_down(int t){
	if(a[t].lazy==0) return;
	a[tl].sum+=(a[tl].r-a[tl].l+1)*a[t].lazy;
	a[tr].sum+=(a[tr].r-a[tr].l+1)*a[t].lazy;
	a[tl].sum%=MOD;
	a[tr].sum%=MOD; 
	a[tl].maxn+=a[t].lazy;
	a[tr].maxn+=a[t].lazy;
	a[tl].minn+=a[t].lazy;
	a[tr].minn+=a[t].lazy;
	a[tl].lazy+=a[t].lazy;
	a[tr].lazy+=a[t].lazy;
	a[t].lazy=0;
	return;
}
void add(int t,int l,int r,int w){
	if(a[t].minn>w) return;
	if(a[t].maxn<=w&&a[t].l>=l&&a[t].r<=r){
		a[t].sum+=(a[t].r-a[t].l+1)*w;
		a[t].sum%=MOD;
		a[t].maxn+=w;
		a[t].minn+=w;
		a[t].lazy+=w;
		return;
	}
	push_down(t);
	int mid=(a[t].l+a[t].r)>>1;
	if(mid>=l) add(tl,l,r,w);
	if(mid<r) add(tr,l,r,w); 
	push_up(t);
}
ull query_sum(int t,int l,int r){
	if(a[t].l>=l&&a[t].r<=r) return a[t].sum;
	push_down(t);
	int mid=(a[t].l+a[t].r)>>1;
	ull o=0;
	if(mid>=l) o+=query_sum(tl,l,r);
	if(mid<r) o+=query_sum(tr,l,r);
	return o%MOD;
}
int query_num(int t,int l,int r){
	if(a[t].l>=l&&a[t].r<=r){
		if(a[t].maxn<=k) return a[t].r-a[t].l+1;
		if(a[t].minn>k) return 0;
	}
	push_down(t);
	int mid=(a[t].l+a[t].r)>>1;
	int o=0;
	if(mid>=l) o+=query_num(tl,l,r);
	if(mid<r) o+=query_num(tr,l,r);
	return o;
}
int main()
{
	freopen("moon.in","r",stdin);
	freopen("moon.out","w",stdout);
	n=readd();
	q=readd();
	for(int i=1;i<=n;i++) c[i]=readu();
	build(1,1,n);
	while(q--){
		f=readd();
		s=readd();
		t=readd();
		if(f==1){
			k=readu();
			add(1,s,t,k);
		}
		if(f==2)
			printf("%llu\n",query_sum(1,s,t));
		if(f==3){
			k=readu();
			printf("%d\n",query_num(1,s,t));
		}
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
