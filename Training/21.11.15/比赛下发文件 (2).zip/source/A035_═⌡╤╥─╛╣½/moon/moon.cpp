#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cmath>
#define ll long long
using namespace std;
const int M=1e9+7;
ll l,r,x,n,q,oq;
ll a[100001];
ll i;
void q1(ll l,ll r,ll x){
	for(i=l;i<=r;i++){
		if(a[i]<=x){
			a[i]+=x;
		}
	}
}
ll int q2(ll l,ll r){
	ll int ans=0;
	for(i=l;i<=r;i++){
		ans+=a[i]%M;
		ans=ans%M;
	}
	return ans;
}
ll int q3(ll l,ll r,ll x){
	ll int sum=0;
	for(i=l;i<=r;i++){
		if(a[i]<=x){
			sum++;
		}
	}
	return sum;
}
int main()
{
	freopen("moon.in","r",stdin);
	freopen("moon.out","w",stdout);
	cin>>n>>q;
	for(i=1;i<=n;i++){
		cin>>a[i];
	}
	while(q--){
		cin>>oq;
		if(oq==1){
			cin>>l>>r>>x;
			q1(l,r,x);
			continue;
		}
		if(oq==2){
			cin>>l>>r;
			cout<<q2(l,r)<<endl;
			continue;
		}
		if(oq==3){
			cin>>l>>r>>x;
			cout<<q3(l,r,x)<<endl;
			continue;
		}
	}
	return 0;
}
