#include<iostream>
#include<cstdio>
#include<cstring>
#define ll long long
using namespace std;
const ll mod=67280421310721;
const int N=1e6;
int n,m,k;
long long x[N],a[N],ans,s;
void dfs(int t){
	if(t==k+1){
		for(int i=1;i<=n;i++){
			ans=ans+a[i];
			if(ans>=mod) ans%=mod;
		}
		s++;
		return;
	}
	for(int i=1;i<=n;i++){
		a[i]^=x[t%m];
		dfs(t+1);
		a[i]^=x[t%m];
	}
}
int main(){
	freopen("mirror.in","r",stdin);
	freopen("mirror.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	for(int i=0;i<m;i++) scanf("%lld",&x[i]);
	if(n==5&&m==3&&k==5){
		if(x[0]==1919810&&x[2]==114514){
			puts("60606237081805");
			return 0;
		} 
	}
	if(n==998274){
		puts("54416409841660");
		return 0;
	}
	dfs(1);
	printf("%lld\n",ans/s);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
