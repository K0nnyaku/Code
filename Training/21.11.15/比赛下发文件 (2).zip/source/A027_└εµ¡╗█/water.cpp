#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<cmath>
using namespace std;
int k,v;
int main(){
	freopen("water.in","r",stdin);
	freopen("water.out","w",stdout);
	scanf("%d%d",&k,&v);
	if(v==1){
		printf("%d %d\n",k+1,(k-1)*2+1);
		printf("%d %d 1\n",1,k+1);
		for(int i=2;i<k;i++) printf("%d %d 1\n",1,i);
		printf("%d %d %d\n",1,k,k+v-2);
		for(int i=2;i<=k;i++) printf("%d %d 1\n",i,k+1);
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
