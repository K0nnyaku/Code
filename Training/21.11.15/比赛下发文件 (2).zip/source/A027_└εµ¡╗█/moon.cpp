#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<cmath>
using namespace std;
const int N=1e5+5;
int n,q,opt,l,r,shu[N],p,ans;
long long x,a[N],mod=1e9+7,dis[N],net[N];
bool wy=0,b[N*4];
__int128 sum[N];
struct qwe{
	int l,r,id,cc;
	long long x;
}A[N];
void boli(){
	for(int i=1;i<=q;i++){
		scanf("%d",&opt);
		if(opt==1){
			scanf("%d%d%lld",&l,&r,&x);
			for(int j=l;j<=r;j++) if(a[j]<=x) a[j]+=x;
		}
		if(opt==2){
			long long s=0;
			scanf("%d%d",&l,&r);
			for(int j=l;j<=r;j++){
				s+=a[j];
				if(s>=mod) s%=mod;
			}
			printf("%lld\n",s);
		}
		if(opt==3){
			int s=0;
			scanf("%d%d%lld",&l,&r,&x);
			for(int j=l;j<=r;j++){
				if(a[j]<=x) s++;
			}
			printf("%d\n",s);
		}
	}
}
bool mm(qwe a,qwe b){
	if(a.id!=b.id) return a.id>b.id;
	return a.x<b.x;
}
bool nn(qwe a,qwe b){
	return a.cc<b.cc;
}
void push_up(int t){
	b[t]=(b[t<<1]&b[t<<1|1]);
}
void zha(int t,int l,int r,int x,int y,long long z){
	if(b[t]) return;
	int mid=(l+r)>>1;
	if(l>=x&&r<=y){
		for(int i=l;i<=r;i++) if(a[i]<=z) ans++;
		return;
	}
	if(x<=mid) zha(t<<1,l,mid,x,y,z);
	if(y>mid) zha(t<<1|1,mid+1,r,x,y,z);
	push_up(t);
}
int main(){
	freopen("moon3.in","r",stdin);
	freopen("saf","w",stdout);
	scanf("%d%d",&n,&q);
	for(int i=1;i<=n;i++) scanf("%lld",&a[i]);
	if(n<=5000&&q<=5000){
		boli();
		return 0;
	}
	for(int i=1;i<=q;i++){
		scanf("%d",&opt);
		A[i].id=opt;
		A[i].cc=i;
		if(opt==1){
			wy=1;
			scanf("%d%d%lld",&l,&r,&x);
			A[i].l=l;A[i].r=r,A[i].x=x;
		}
		if(opt==2){
			scanf("%d%d",&l,&r);
			A[i].l=l;A[i].r=r; 
		}
		if(opt==3){
			scanf("%d%d%lld",&l,&r,&x);
			A[i].l=l;A[i].r=r,A[i].x=x;
		}
	}
	if(!wy){
		for(int i=1;i<=n;i++) sum[i]=sum[i-1]+a[i];
		for(int i=0;i<n;i++) net[i]=i+1;
		sort(A+1,A+1+q,mm);
		for(int i=1;i<=n;i++){
			if(A[i].id==2) break;
			zha(1,1,n,A[i].l,A[i].r,A[i].x);
			shu[A[i].cc]=ans;
		}
		sort(A+1,A+1+q,nn);
		for(int i=1;i<=q;i++){
			if(A[i].id==2){
				printf("%lld\n",(long long)((sum[r]-sum[l-1])%mod));
			}
			else{
				printf("%d\n",shu[i]);
			}
		}
		return 0;
	} 
	fclose(stdin);
	fclose(stdout);
	return 0;
}
