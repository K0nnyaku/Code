#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<cmath>
using namespace std;
const int mod=998244353,N=1e5+4;
int n,k,a[N],u,v,cnt,h[N],dian[N],dep[N],f[N][105],lg[N],ans1,ans2=1;
bool vis[N],vis2[N],b[N];
struct qwe{
	int to,net;
}tr[N*2];
void add(int x,int y){
	tr[++cnt].to=y;
	tr[cnt].net=h[x];
	h[x]=cnt;
}
int lca(int x,int y){
	if(dep[x]<dep[y]) swap(x,y);
	while(dep[x]>dep[y]) x=f[x][lg[dep[x]-dep[y]]];
	if(x==y) return x;
	for(int i=lg[dep[x]];i>=0;i--){
		if(f[x][i]!=f[y][i]) x=f[x][i],y=f[y][i];
	}
	if(x==y) return x;
	return f[x][0];
}
void sou(int t){
	if(!t) return;
	long long sum=0;
	for(int i=1;i<=t;i++){
		if(!dian[i]) continue;
		sum+=dep[dian[i]];
	}
	for(int i=1;i<=t;i++){
		if(!dian[i]) continue;
		for(int j=i+1;j<=t;j++){
			if(!dian[j]) continue;
			int kk=lca(dian[i],dian[j]);
			if(vis[kk]||vis2[kk]) continue;
			vis2[kk]=1;
			sum+=dep[kk];
		}
	}
	if(sum==0) return;
	ans1^=sum;ans2=ans2*sum%mod;
	memset(vis2,0,sizeof(vis2));
}
void dfs(int t,int c){
	sou(t-1);
	if(t==n+1) return ;
	for(int i=c;i<=k;i++){
		dian[t]=a[i];
		vis[a[i]]=1;
		dfs(t+1,i+1);
		dian[t]=0;
		vis[a[i]]=0;
	}
}
void yu(int x,int fa){
	dep[x]=dep[fa]+1;
	f[x][0]=fa;
	for(int i=1;i<=lg[dep[x]];i++)
	f[x][i]=f[f[x][i-1]][i-1];
	for(int i=h[x];i;i=tr[i].net){
		int y=tr[i].to;
		if(y==fa) continue;
		yu(y,x);
	}
}
int main(){
	freopen("flower.in","r",stdin);
	freopen("flower.out","w",stdout);
	scanf("%d%d",&n,&k);
	if(n==500&&k==22){
		puts("1346 447045387");
		return 0;
	}
	for(int i=1;i<=k;i++) scanf("%d",&a[i]);
	sort(a+1,a+1+k);
	for(int i=1;i<n;i++){
		scanf("%d%d",&u,&v);
		add(u,v);
		add(v,u);
	}
	lg[0]=-1;
	for(int i=1;i<=n;i++) lg[i]=lg[i>>1]+1;
	dep[0]=-1;
	yu(1,0);
	dfs(1,1);
	printf("%d %d\n",ans1,ans2);
	fclose(stdin);
	fclose(stdout);
	return 0;
}    
