#include <bits/stdc++.h>
#define int long long
#define Efor(xx, yy) for(int xx = Head[yy]; xx; xx = Next[xx])
#define Lfor(xx, yy, zz, xyz, ...) for(int xx = yy, ##__VA_ARGS__; xx <= zz; xx += xyz)
#define Rfor(xx, yy, zz, xyz, ...) for(int xx = yy, ##__VA_ARGS__; xx >= zz; xx -= xyz)
using namespace std;
struct FastIN {
    char buf[(1 << 21) + 100], *p, *e;
    int getChar() {
        if (p == e) p = buf, e = buf + fread(buf, 1, (1 << 21), stdin);
        return p == e ? EOF : *p++;
    }
    template<typename T>
    FastIN& operator >> (T& x) {
        char c, l;
        for (c = 0; !isdigit(c); c = getChar()) l = c;
        for (x = 0; isdigit(c); c = getChar()) x = x * 10 - '0' + c;
        if (l == '-') x = -x;
        return *this;
    }
} IN;
const int kN = 1e6 + 16, Mod = 998244353;
int n, k, A[kN];
bool Use[kN], Tmp[kN];
int Dep[kN], ST[kN][18];
int XOR, TIMES = 1;
int tot, Head[kN], Next[kN], Ver[kN], Lca(int, int);
void Ins(int, int), BFS(int), DFS(int), Work(), Solve();
signed main() {
#ifdef FIO
    freopen("D:/Code/In.in", "r", stdin);
    freopen("D:/Code/Out.out", "w", stdout);
#else
    freopen("flower.in", "r", stdin);
    freopen("flower.out", "w", stdout);
#endif
    IN >> n >> k;
    Lfor (i, 1, k, 1) IN >> A[i];
    Lfor (i, 1, n - 1, 1, u, v) {
        IN >> u >> v;
        Ins(u, v), Ins(v, u);
    }
    Solve();
    cout << XOR << " " << TIMES;
    return 0;
}
void Ins(int x, int y) {
    Ver[++tot] = y;
    Next[tot] = Head[x];
    Head[x] = tot;
}
void Work() {
    int sum = 0, flag = 0;
    // cout << "Tree: \n";
    Lfor (i, 1, k, 1) {
        if (Use[i]) Tmp[A[i]] = 1, flag = 1;
        // if (Tmp[A[i]]) cout << "\t" << A[i] << "\n";
        // Tmp[i] = Use[i];
        if (Tmp[A[i]]) sum += Dep[A[i]];
    }
    Lfor (i, 1, k, 1)
        if (Tmp[A[i]]) 
            Lfor (j, 1, k, 1)
                if (Tmp[A[j]] and !Tmp[Lca(A[i], A[j])]) {
                    // cout << "\t" << Lca(A[i], A[j]) << "\n";
                    Tmp[Lca(A[i], A[j])] = 1;
                    sum += Dep[Lca(A[i], A[j])];
                }
    Lfor (i, 1, n, 1) Tmp[i] = 0;
    // cout << "sum : " << sum << "\n";
    if (flag) {
        XOR ^= sum;
        TIMES = (TIMES * sum) % Mod;
    }
    
}
void DFS(int x) {
    if (x == k + 1) {
        Work(); return ;
    }
    DFS(x + 1);
    Use[x] = 1;
    DFS(x + 1);
    Use[x] = 0;
}
void Solve() {
    BFS(1);
    // cout << Lca(3, 4);
    // return ;
    DFS(1);
}
void BFS(int St) {
    int LOG = log2(n);
    queue <int> Q;
    Dep[St] = 0, Q.push(St);
    while (Q.size()) {
        int x = Q.front(); Q.pop();
        Efor (e, x) {
            int y = Ver[e];
            if (Dep[y] or y == St) continue;
            // cout << x << " -> " << y  << "\n";
            Dep[y] = Dep[x] + 1;
            ST[y][0] = x;
            Lfor (i, 1, LOG, 1) ST[y][i] = ST[ST[y][i - 1]][i - 1];
            Q.push(y);
        }
    }
}
int Lca(int x, int y) {
    int LOG = log2(n);
    if (Dep[x] < Dep[y]) swap(x, y);
    Rfor (i, LOG, 0, 1)
        if (Dep[ST[x][i]] >= Dep[y])
            x = ST[x][i];
    if (x == y) return x;
    Rfor (i, LOG, 0, 1)
        if (ST[x][i] != ST[y][i])
            x = ST[x][i], y = ST[y][i];
    return ST[y][0];
}

