#include <bits/stdc++.h>
#define int long long
#define Efor(xx, yy) for(register int xx = Head[yy]; xx; xx = Next[xx])
#define Lfor(xx, yy, zz, xyz, ...) for(register int xx = yy, ##__VA_ARGS__; xx <= zz; xx += xyz)
#define Rfor(xx, yy, zz, xyz, ...) for(register int xx = yy, ##__VA_ARGS__; xx >= zz; xx -= xyz)
using namespace std;
struct FastIN {
    char buf[(1 << 21) + 100], *p, *e;
    int getChar() {
        if (p == e) p = buf, e = buf + fread(buf, 1, (1 << 21), stdin);
        return p == e ? EOF : *p++;
    }
    template<typename T>
    FastIN& operator >> (T& x) {
        char c, l;
        for (c = 0; !isdigit(c); c = getChar()) l = c;
        for (x = 0; isdigit(c); c = getChar()) x = x * 10 - '0' + c;
        if (l == '-') x = -x;
        return *this;
    }
} IN;
const int kN = 1e6 + 16, INF = ~0ull >> 1, Mod = 1e9 + 7;
int n, q;
int A[kN];
signed main() {
#ifdef FIO
    freopen("D:/Code/In.in", "r", stdin);
    freopen("D:/Code/Out.out", "w", stdout);
#else
    freopen("moon.in", "r", stdin);
    freopen("moon.out", "w", stdout);
#endif

    IN >> n >> q;
    Lfor (i, 1, n, 1) IN >> A[i];

    Lfor (i, 1, q, 1, opt, l, r, x) {

        IN >> opt >> l >> r;

        if (opt == 1) {
            IN >> x;
            Lfor (k, l, r, 1) A[k] += x * (A[k] <= x);
        } else if (opt == 2) {
            register int sum = 0;
            Lfor (k, l, r, 1) sum = (sum + A[k]) % Mod;
            cout << sum << '\n';
        } else {
            IN >> x;
            register int cnt = 0;
            Lfor (k, l, r, 1) cnt += (A[k] <= x);
            cout << cnt << '\n';
        }
    }
    // cerr << "\n" << clock() << "(ms)";
    return 0;
}