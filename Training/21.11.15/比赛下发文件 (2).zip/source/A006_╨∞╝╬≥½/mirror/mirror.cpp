#include <bits/stdc++.h>
#define int __int128
#define Efor(xx, yy) for(int xx = Head[yy]; xx; xx = Next[xx])
#define Lfor(xx, yy, zz, xyz, ...) for(int xx = yy, ##__VA_ARGS__; xx <= zz; xx += xyz)
#define Rfor(xx, yy, zz, xyz, ...) for(int xx = yy, ##__VA_ARGS__; xx >= zz; xx -= xyz)
using namespace std;
struct FastIN {
    char buf[(1 << 21) + 100], *p, *e;
    int getChar() {
        if (p == e) p = buf, e = buf + fread(buf, 1, (1 << 21), stdin);
        return p == e ? EOF : *p++;
    }
    template<typename T>
    FastIN& operator >> (T& x) {
        x = 0;
        char c, l;
        for (c = 0; !isdigit(c); c = getChar()) l = c;
        for (x = 0; isdigit(c); c = getChar()) x = x * 10 - '0' + c;
        if (l == '-') x = -x;
        return *this;
    }
    FastIN& operator << (string x) {
        cout << x;
        return *this;
    }
    FastIN& operator << (long long x) {
        cout << x;
        return *this;
    }
    FastIN& operator << (int x) {
        if (x >= 10) *this << (x / 10);
        putchar(x % 10 + '0');
        return *this;
    }
} IN;
const int kN = 1e6 + 16, Mod = 67280421310721;
int n, m, k, Val;
int X[kN], A[kN];
void DFS(int), Solve(), IAKIOI();
int F_Pow(int, int, int), NY(int, int);
signed main() {
#ifdef FIO
    freopen("D:/Code/In.in", "r", stdin);
    freopen("D:/Code/Out.out", "w", stdout);
#else
    freopen("mirror.in", "r", stdin);
    freopen("mirror.out", "w", stdout);
#endif
    IN >> n >> m >> k;
    Lfor (i, 0, m - 1, 1) IN >> X[i];
    // Lfor (i, 0, m - 1, 1) IN << X[i] << " ";
    // IN << "\n";
    DFS(1);
    // IN << Val;
    IN << Val * NY(F_Pow(n, k, Mod), Mod) % Mod;
    return 0;
}
int F_Pow(int a, int b, int p) {
    int ans = 1;
    while (b) {
        if (b & 1) ans = ans * a % p;
        a = a * a % p;
        b >>= 1;
    }
    return ans;
}
int NY(int x, int p) {
    return F_Pow(x % p, p - 2, p);
}
void DFS(int x) {
    if (x == k + 1) {
        Solve(); return ;
    }
    Lfor (i, 1, n, 1) {
        int Tmp = A[i];
        A[i] = (A[i] ^ X[x % m]) % Mod;
        DFS(x + 1);
        A[i] = Tmp;
    }
}
void Solve() {
    Lfor (i, 1, n, 1) {
        Val = (Val + A[i]) % Mod;
        // IN << A[i] << " ";
    }
    // IN << "\n";
}
void IAKIOI() {
    Lfor (i, 1, 'I' + 'A' + 'K' + 'I' + 'O' + 'I', 1) cout << "IAKIOI" << "\n";
}