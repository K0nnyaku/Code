#include<cstdio>
#include<iostream>
#include<algorithm>
#include<cmath>
#include<cstring>
#include<queue>
#include<map>
#include<set>
#include<cstdlib>
#define LL long long
using namespace std;
int n,k,a[508],s[208],tot,ans1,cnt,head[100005],dep[100005],p[100005][30],u,v,sum,flag,mod=998244353,vis[208];
LL ans2=1;
int f[5006][5006];
struct edge{
	int nt,to;
}e[1000002];
void add(int u,int v)
{
	++cnt;
	e[cnt].to=v;
	e[cnt].nt=head[u];
	head[u]=cnt;
}
inline int read()
{
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9')
	{
		if(ch=='-')
		f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9')
	{
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}

void dfs(int x,int fa)
{
	dep[x]=dep[fa]+1;
	p[x][0]=fa;
	for(int i=head[x];i;i=e[i].nt)
	{
		int v=e[i].to;
		if(v==fa) continue;
		dfs(v,x);	
	}
}
int LCA(int a,int b)
{
	if(dep[a]>dep[b] ) swap(a,b);
	for(int i=20;i>=0;i--)
	{
		if(dep[p[b][i]]>=dep[a])
		b=p[b][i];
	}
	if(a==b) return a;
	for(int i=20;i>=0;i--)
	{
		if(p[a][i]!=p[b][i])
		{
			a=p[a][i];
			b=p[b][i];
		}
	}
	return p[b][0];
}

int main()
{
    freopen("flower.in","r",stdin);
	freopen("flower.out","w",stdout);
	n=read();k=read();
	for(int i=1;i<=k;i++)
	a[i]=read();
	for(int i=1;i<n;i++)
	{
			u=read();v=read();
			add(u,v);
			add(v,u);
	}
	dfs(1,0);	
	for(int j=1;j<=20;j++)
	for(int i=1;i<=n;i++)
	{
		p[i][j]=p[p[i][j-1]][j-1];
	}
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=n;j++)
		{
			if(i!=j)
			{
				f[i][j]=LCA(i,j);			
			} 	
		}		
	}
	for(int i=0;i<=n;i++)
	{
		dep[i]--;
	}
	for(int S=0;S<pow(2,k);S++)
	{
		memset(s,0,sizeof(s));
		memset(vis,0,sizeof(vis));
		tot=0,sum=0;
	  for(int j=0;j<k;j++)
	   {
		if(((S&(1<<j))!=0)&&vis[a[j+1]]==0)
		{
			s[++tot]=a[j+1];
		vis[a[j+1]]=1;
		}
	   }
	   if(tot==0) continue; 
	   int top=tot;
	   for(int i=1;i<=tot;i++)
	   for(int j=1;j<=tot;j++)
	   {
	   	if(s[i]!=s[j]&&vis[f[s[i]][s[j]]]==0)
	   	{
	   		s[++top]=f[s[i]][s[j]];vis[f[s[i]][s[j]]]=1;
		}
	   	
	   }
	   for(int i=1;i<=top;i++)
	   {
	   	sum+=dep[s[i]];
	   }
	   if(flag==0)
	   {
	   	 ans1=sum;
	   	 flag=1;
	   }
	   else{
	   	ans1^=sum;
	   }
	 ans2=((ans2*(LL)sum))%mod;
	}
	 printf("%d %d",ans1,ans2%mod);
	return 0;
}
