#include<cstdio>
#include<iostream>
#include<algorithm>
#include<cmath>
#include<cstring>
#include<queue>
#include<map>
#include<set>
#include<cstdlib>
#define LL long long
#define lt k<<1
#define rt k<<1|1
using namespace std;
const LL mod=1000000007;
LL l,r,x,op,a[800009],n,q;
inline LL read()
{
	LL x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9')
	{
		if(ch=='-')
		f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9')
	{
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
int main()
{
	freopen("moon.in","r",stdin);
	freopen("moon.out","w",stdout);
	n=read();
	q=read();
	for(int i=1;i<=n;i++)
	{
		a[i]=read();
	}
	for(int i=1;i<=q;i++)
	{
		op=read();
		if(op==1) 
		{
			l=read();r=read();x=read();
			for(int j=l;j<=r;j++)
			{
				if(a[j]<=x) a[j]+=x;
			}
		}
		if(op==2)
		{
		LL moon=0;
			l=read();r=read();
			for(int j=l;j<=r;j++)
			{
				moon=(moon+a[j])%mod;
			}
			printf("%lld\n",moon%mod);
		}
		if(op==3)
		{
			LL moon=0;
				l=read();r=read();x=read();
				for(int j=l;j<=r;j++)
			{
				if(a[j]<=x) moon++;
			}
			printf("%lld\n",moon);
		}
	}
	return 0;
}
