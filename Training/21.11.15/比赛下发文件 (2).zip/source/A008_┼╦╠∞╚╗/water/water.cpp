#include<cstdio>
using namespace std;
int k, v;

int main() {
	freopen("water.in","r",stdin);
	freopen("water.out","w",stdout);
	scanf("%d%d",&k,&v);
	
	if (k + 1 <= 30) {
		printf("%d %d\n",k + 1, 2 * k - 1);
		printf("1 %d %d\n",k + 1,v);
		for (int i = 2; i <= k; i++) {
			printf("%d %d 1\n",i-1,i);
			printf("%d %d %d\n",i,k+1,v); 
		}
	}
	else {
		int cnt = 0, kk = k;
		while (kk) {
			kk >>= 1;
			cnt++;
		}
		int sum = cnt * 2;
		printf("%d %d\n",sum,(sum - 2) << 1);
		
//		int Min = v / cnt, Max = (k + v - 1) / cnt;
//		printf("Min = %d Max = %d\n",Min,Max);
		printf("1 2 1\n1 3 1\n");
		for (int i = 2; i <= sum - 3; i++) {
			if (i & 1) {
//				printf("%d %d %d\n",i,i+1,Min);
//				printf("%d %d %d\n",i,i+2,Max);
				printf("%d %d 2\n",i,i+1);
				printf("%d %d 1\n",i,i+2);
			}
			else {
//				printf("%d %d %d\n",i,i+2,Min);
//				printf("%d %d %d\n",i,i+3,Min);
				printf("%d %d 1\n",i,i+2);
				printf("%d %d 0\n",i,i+3);
			}
		}
		
//		printf("%d %d %d\n",sum - 2, sum, Min + (v % cnt));
//		printf("%d %d %d\n",sum - 1, sum, Max + ((k + v - 1) % cnt));	
		printf("%d %d %d\n",sum - 2, sum, v - cnt + 1);
		printf("%d %d %d\n",sum - 1, sum, k + v - cnt);
	}
	
	return 0;
}
