#include<cstdio>
#include<algorithm>
#define int long long
using namespace std;
const int N = 5e3 + 55;
bool Flag = true;
int n, m, X[N], P[N];
int Id[N], A[N], Vis[N], Ans[N];

int Abs(int x) {
	if (x < 0)	return -x;
	else	return x;
}

void Solve(int Num, int Last, int Sum) {
	if (Flag)	return ;
	if (Sum > m)	return ;
//	printf("Num = %d last = %d sum = %d\n",Num,Last,Sum);
	if (Num == n + 1) {
//		for (int i = 1; i <= n; i++) {
//			printf("%d ",A[i]); 
//		} printf("\n");
		Flag = 1;
		for (int i = 1; i <= n; i++)	Ans[i] = A[i]; 
		return ;
	}
	
	for (int i = 1; i <= n; i++) {
		if (Vis[i])	continue;
		Vis[i] = 1; A[Num] = i;
		Solve(Num + 1, Id[i], Last ? Sum + Abs(X[Id[i]] - X[Last]) : Sum);
		Vis[i] = 0;
	}
}

signed main() {
	freopen("gem.in","r",stdin);
	freopen("gem.out","w",stdout);
	scanf("%lld%lld",&n,&m);
	for (int i = 1; i <= n; i++) {
		scanf("%lld%lld",&X[i],&P[i]);
		if (P[i] != i)	Flag = false;
		Id[P[i]] = i;
	}
	
	if (Flag) {
		for (int i = 1; i <= n; i++)	printf("%lld ",i);
	}
	else {
		Solve(1, 0, 0);
		for (int i = 1; i <= n; i++)	printf("%lld ",Ans[i]);
	}
	
	return 0;
} 
