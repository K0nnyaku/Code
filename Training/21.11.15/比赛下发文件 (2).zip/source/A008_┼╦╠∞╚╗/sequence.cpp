#include<cstdio>
#include<algorithm>
using namespace std;
const int N = 1e5 + 5, M = 1e6 + 5;
int n, A[N], Ans[N];

int main() {
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
	scanf("%d",&n);
	for (int i = 1; i <= n; i++)	scanf("%d",&A[i]);
	for (int i = 1; i <= n; i++)	Ans[i] = M;
	
	for (int i = 1; i <= n; i++) {
		int Max = 0, Min = M;
		for (int j = i; j <= n; j++) {
			Max = max(Max, A[j]); Min = min(Min, A[j]);
			Ans[j - i + 1] = min(Ans[j - i + 1], Max - Min);
		}
	}
	
	for (int i = 2; i <= n; i++)	printf("%d\n",Ans[i]);
	return 0;
}
