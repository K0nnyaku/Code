#include<cstdio>
#include<iostream>
//#define int __int128
#define int long long
using namespace std;
const int N = 10;
int n, m, k, Ny, Ans;
int X[N], A[N], Mod = 67280421310721;

int Q_pow(int a, int b) {
	int Ans = 1;
	while (b) {
		if (b & 1)	Ans = (__int128)1 * Ans * a % Mod;
		a = (__int128)1 * a * a % Mod; b >>= 1; 
//		cout << "Ans = " << Ans << endl;
	}
	return Ans;
}

void Solve(int Num, int Sum) {
//	cout << Num << "---" << endl;
	if (Num == k + 1) {
		Ans = (Ans + (__int128)1 * Ny * Sum % Mod) % Mod;
		return ;
	}
	
	for (int i = 1; i <= n; i++) {
		int bef = A[i];
		A[i] ^= X[Num % m];
		Solve(Num + 1, Sum - bef + A[i]);
		A[i] = bef;
	}
} 

signed main() {
	freopen("mirror.in","r",stdin);
	freopen("mirror.out","w",stdout);
	scanf("%lld%lld%lld",&n,&m,&k);
//	n = Read(); m = Read(); k = Read();
	for (int i = 0; i < m; i++)	scanf("%lld",&X[i]);//X[i] = Read();
	
	int Gl = Q_pow(n, k);
//	cout << "Gl = " << Gl << endl;
	Ny = Q_pow(Gl, Mod - 2);
//	cout << Ny << endl;
	Solve(1, 0);
	
	cout << Ans;
	
	return 0;
} 
