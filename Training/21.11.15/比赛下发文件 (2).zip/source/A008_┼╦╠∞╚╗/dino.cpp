#include<cstdio>
#include<algorithm>
using namespace std;
const int N = 2e5 + 55;
int n, k, m, F[N], Vis[N], X[N], T[N];

void Handle(int l) {
	for (int i = l; i <= n; i++) {
		F[i] = N;
		if (Vis[i])	continue;
		F[i] = F[i - 1];
		if (i - k >= 1)	F[i] = min(F[i], F[i - k] + 1);
	}
}

int main() {
	freopen("dino.in","r",stdin);
	freopen("dino.out","w",stdout);
	scanf("%d%d%d",&n,&k,&m);
	
	for (int i = 1; i <= m; i++) {
		scanf("%d%d",&X[i],&T[i]);
		Vis[X[i]] = 1; Handle(X[i]);
		if (F[T[i]] == N)	printf("-1\n");
		else	printf("%d\n",F[T[i]]);
	}
	
	return 0;
} 
