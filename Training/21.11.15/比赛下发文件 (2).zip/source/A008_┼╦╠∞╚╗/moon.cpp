#include<bits/stdc++.h>
#define int long long
using namespace std;
const int N = 1e5 + 55;
int n, q, opt, l, r, x, Ans;
int A[N], Sum[N], Mod = 1e9 + 7;
int m, B[N], Va[N], Tree[N];

int Read() {
	int x = 0; char ch = getchar();
	while (ch < '0' or ch > '9')	ch = getchar();
	while (ch >= '0' and ch <= '9')	{
		x = x * 10 + ch - '0';
		ch = getchar();
	}
	return x;
}

int Lowbit(int x) {
	return x & (-x);
} 

void Add(int x) {
	while (x <= n) {
		Tree[x]++;
		x += Lowbit(x);
	}
}

int Query(int x) {
	int Sum = 0;
	while (x > 0) {
		Sum += Tree[x];
		x -= Lowbit(x);
	}
	return Sum;
}

signed main() {
	freopen("moon.in","r",stdin);
	freopen("moon.out","w",stdout);
	n = Read(); q = Read();
	for (int i = 1; i <= n; i++) {
		A[i] = Read(); 
		Sum[i] = A[i] % Mod;
	}
	
//	if (n <= 5e3 and q <= 5e3) {
		for (int i = 1; i <= q; i++) {
			opt = Read(); l = Read(); r = Read();
			Ans = 0;
			if (opt == 2) {
				for (int j = l; j <= r; j++) {
					Ans = (Ans + Sum[j]) % Mod;
				}
				cout << Ans << '\n';
			}
			else {
				x = Read();
				if (opt == 1) {
					for (int j = l; j <= r; j++) {
						if (A[j] <= x) {
							A[j] += x; 
							Sum[j] = (Sum[j] + x) % Mod;
						}
					}
				}
				else {
					for (int j = l; j <= r; j++) {
						if (A[j] <= x)	Ans++;
					}
					cout << Ans << '\n';
				}
			}
		}
//	}
//	else {
//		for (int i = 1; i <= n; i++) {
//			Sum[i] = (Sum[i] + Sum[i - 1]) % Mod;
//		}
//		sort(A + 1, A + n + 1);
//		for (int i = 1; i <= n; i++) {
//			if (A[i] != A[i - 1])	m++;
//			Add(m);
//		}
//		
//		m = unique(A + 1, A + n + 1) - A;
//		for (int i = 1; i <= q; i++) {
//			opt = Read(); l = Read(); r = Read();
//			Ans = 0;
//			if (opt == 2)	cout <<  (Sum[r] - Sum[l - 1] + Mod) % Mod << '\n'; 
//			else {
//				x = Read();
//				int id = upper_bound(A + 1, A + m + 1, x) - A - 1;
//				cout << Query(id) << '\n';
//			}
//		}
//	}
	
	return 0;
}

/*
5 5
2 3 4 3 4
1 2 4 3
2 2 5
3 1 4 4
1 1 3 3
2 1 5
*/
