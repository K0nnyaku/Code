#include<cstdio>
#include<cstring>
using namespace std;
const int N = 1e3 + 55;
int n, m, k, Mod = 998244353;
int H[N], L[N], Ans;

void Init() {
	Ans = 0;
	memset(H, 0, sizeof(H));
	memset(L, 0, sizeof(L));
}

void Solve(int Num) {
	if (Num == n + 1) {
		Ans++;
		if (Ans == Mod)	Ans = 0;
		return ;
	}
	
	if (!H[Num]) {
		for (int i = 1; i <= m; i++) {
			if (L[i])	continue;
			if (i < m and !L[i + 1]) {
				L[i] = L[i + 1] = 1;
				Solve(Num + 1);
				L[i] = L[i + 1] = 0;
			}
			if (Num < n and !H[Num + 1]) {
				L[i] = H[Num + 1] = 1;
				Solve(Num + 1);
				L[i] = H[Num + 1] = 0; 
			}
		}
	}
	Solve(Num + 1);
}

int main() {
	freopen("count.in","r",stdin);
	freopen("count.out","w",stdout);
	while (~scanf("%d%d%d",&n,&m,&k)) {
		Init();
		for (int i = 1, x, y; i <= k; i++) {
			scanf("%d%d",&x,&y); H[x] = L[y] = 1;
		}
		
		Solve(1);
		printf("%d\n",Ans);
	}
	
	return 0;
}
