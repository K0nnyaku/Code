#include<iostream>
#include<cstdio>
#include<ctime>
#include<cstdlib>
#include<vector>
using namespace std;
const int N=2002021;
int n; vector<int> q[N];
int a[N],cnt[N],vis[N],b[N],f[N],g[N];
void get(int x,int *stk,int &w){
//	cerr<<"x="<<x<<endl;
//	cerr<<"in";
	int cs=x; x=a[x]; stk[w=1]=cs;
	while(x!=cs){
		stk[++w]=x,x=a[x];
//		cerr<<"x="<<x<<endl;
	}
//	cerr<<"out";
}
void solve(int x){
//	cerr<<"in!"<<endl;
	int num=0; get(x,f,num);
	if(num==1)return b[x]=a[x],void();
//	int w=x/2+2,bg=x;
//	b[bg]=f[w],bg=f[bg];
	b[x]=f[num/2+2];
	for(int i=2;i<=num/2;i++)
		b[f[i]]=f[i+num/2+1];
	for(int i=num/2+2;i<=num;i++)
		b[f[i]]=f[i-num/2];
	b[f[num/2+1]]=x;
//	cerr<<"out!"<<endl;
}
void merge(int x,int y){
//	cerr<<"merge "<<x<<" "<<y<<endl;
	int n1,n2;
	get(x,f,n1); get(y,g,n2);
	for(int i=1;i<=n1;i++)b[f[i]]=g[i];
	for(int i=2;i<=n2;i++)b[g[i-1]]=f[i];
	b[g[n2]]=f[1];
}
int read(){
	int x=0,f=1; char ch=getchar();
	while(ch<'0' || ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0' && ch<='9'){x=x*10+ch-'0';ch=getchar();}
	return x*f;
}
bool check(){
	for(int i=1;i<=n;i++)cout<<b[i]<<" ";cout<<endl;
	for(int i=1;i<=n;i++)cout<<a[i]<<" ";cout<<endl;
	for(int i=1;i<=n;i++)f[i]=b[b[i]];
	for(int i=1;i<=n;i++)
		if(f[i]!=a[i]){cerr<<"error!"<<endl;return 0;}
	return 1;
}
void print(int x){
	if(x>9)print(x/10); putchar(x%10+'0');
}
int main()
{
	freopen("permutation.in","r",stdin);
	freopen("permutation.out","w",stdout);
/*	//test:
	srand((unsigned)time(NULL));
	n=100000;
	for(int i=1;i<=n;i++)b[i]=i;
	for(int i=1;i<=10*n;i++)
		swap(b[rand()%n+1],b[rand()%n+1]);
	for(int i=1;i<=n;i++)a[i]=b[b[i]];
//	cout<<"b:";for(int i=1;i<=n;i++)cout<<b[i]<<" ";cout<<endl;
//	cout<<"a:";for(int i=1;i<=n;i++)cout<<a[i]<<" ";cout<<endl;
	for(int i=1;i<=n;i++){
		if(vis[i])continue;
		int x=a[i],num=1; vis[i]=1;
		while(x!=i)++num,vis[x]=1,x=a[x];
		if(!(num&1))++cnt[num];
	}
	for(int i=1;i<=n;i++)
		if(cnt[i]&1)cerr<<"shit!"<<endl;*/
	n=read();
	for(int i=1;i<=n;i++)a[i]=read();
//	while(1){
//	srand((unsigned)time(NULL));
//	n=1000000;
//	for(int i=1;i<=n;i++)b[i]=i,vis[i]=0,q[i].clear(),a[i]=f[i]=g[i]=0;
//	for(int i=1;i<=n;i++)b[i]=i;
//	for(int i=1;i<=100*n;i++)
//		swap(b[rand()%n+1],b[rand()%n+1]);
//	for(int i=1;i<=n;i++)a[i]=b[b[i]];
//	for(int i=1;i<=n;i++)b[i]=0;
//	cerr<<a[1]<<endl;
//	cerr<<"out";
	for(int i=1;i<=n;i++){
		if(vis[i])continue;
		int num=0; get(i,f,num);
		for(int j=1;j<=num;j++)vis[f[j]]=1;
		if(num&1)solve(i);
		else q[num].push_back(i);
	}
//	cerr<<"out"<<endl;
	for(int i=1;i<=n;i++)
		if(q[i].size()&1)return puts("-1"),0;
	for(int i=1;i<=n;i++){
		if(q[i].empty())continue;
		for(int j=0;j<q[i].size();j+=2)
			merge(q[i][j],q[i][j+1]);
	}
//	if(!check())break;
//	}
	for(int i=1;i<=n;i++)
		print(b[i]),putchar(' ');
//		printf("%d ",b[i]);
	return 0;
}
