#include<cstdio>
#include<cstring>
#include<algorithm>
#include<vector>
using namespace std;
namespace qwq
{
	int f[1000005],L[1000005],R[1000005];
	int find(int x)
	{
		while(f[x]!=x)
			x=f[x]=f[f[x]];
		return x;
	}
	void link(int x,int y)
	{
		x=find(x),y=find(y);
		if(x==y) return;
		f[x]=y;
		L[y]=min(L[x],L[y]);
		R[y]=max(R[x],R[y]);
	}
}
int n,q[1000005][3],b[1000005],bt,c[1000005],ct;
void getb(int x)
{
	b[++bt]=x-1;
	b[++bt]=x;
	b[++bt]=x+1;
}
vector<int> sum[3000005];
void modify(int x,int l,int r,int ql,int qr,int v)
{
	if(l>qr||r<ql) return;
	if(ql<=l&&r<=qr)
	{
		sum[x].push_back(v);
		return;
	}
	int mid=(l+r)/2;
	modify(x*2,l,mid,ql,qr,v);
	modify(x*2+1,mid+1,r,ql,qr,v);
}
void query(int x,int l,int r,int qx,int v)
{
	if(l>qx||r<qx) return;
	int sz=sum[x].size();
	for(int i=0;i<sz;i++)
		qwq::link(sum[x][i],v);
	if(!sum[x].empty()) sum[x].resize(1);
	if(l==r) return;
	int mid=(l+r)/2;
	query(x*2,l,mid,qx,v);
	query(x*2+1,mid+1,r,qx,v);
}
int main()
{
	freopen("interval.in","r",stdin);
	freopen("interval.out","w",stdout); 
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{
		scanf("%d%d%d",&q[i][0],&q[i][1],&q[i][2]);
		if(q[i][0]==1)
		{
			getb(q[i][1]),getb(q[i][2]);
			c[i]=++ct;
			qwq::f[ct]=ct;
			qwq::L[ct]=q[i][1];
			qwq::R[ct]=q[i][2];
		}
	}
	sort(b+1,b+bt+1);
	bt=unique(b+1,b+bt+1)-b-1;
	for(int i=1;i<=n;i++)
	{
		if(q[i][0]==1)
		{
			int l=lower_bound(b+1,b+bt+1,q[i][1])-b;
			int r=lower_bound(b+1,b+bt+1,q[i][2])-b;
			query(1,1,bt,l,c[i]);
			query(1,1,bt,r,c[i]);
			modify(1,1,bt,l+1,r-1,c[i]);
		}
		else
		{
			int x=qwq::find(q[i][1]),y=qwq::find(q[i][2]);
			if(x==y||(qwq::L[y]<qwq::L[x]&&qwq::L[x]<qwq::R[y])
				   ||(qwq::L[y]<qwq::R[x]&&qwq::R[x]<qwq::R[y])) printf("YES\n");
			else printf("NO\n");
		}
	}
	return 0;
}
