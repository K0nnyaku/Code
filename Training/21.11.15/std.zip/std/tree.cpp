#include<cstdio>
#include<cstring>
#include<algorithm>
#include<cassert>
using namespace std;
#define int long long
const int mod=1004535809;
inline int addmod(int x)
{
	return x>=mod?x-mod:x;
}
inline int submod(int x)
{
	return x<0?x+mod:x;
}
int fpow(int x,int y)
{
	int ans=1;
	while(y)
	{
		if(y&1) ans=1ll*ans*x%mod;
		x=1ll*x*x%mod;
		y/=2;
	}
	return ans;
}
int n,a[1005],dp[105][105][105],fr[100005],infr[100005],pn=1e5;
int tans[105];
signed main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	fr[0]=infr[0]=1;
	for(int i=1;i<=pn;i++)
	{
		fr[i]=1ll*fr[i-1]*i%mod;
		infr[i]=fpow(fr[i],mod-2);
	}
	scanf("%lld",&n);
	for(int i=1;i<=n;i++)
	{
		scanf("%lld",&a[i]);
		assert(1<=a[i]&&a[i]<=n);
		a[i]--;
	}
	dp[0][0][0]=1;
	for(int i=1;i<=n;i++)
		for(int j=0;j<=n;j++)
			for(int k=0;k<=n;k++)
			{
				dp[i][j][k]=dp[i-1][j][k];
				if(!j) continue;
				for(int l=0;l<=min(k,a[i]);l++)
					dp[i][j][k]=addmod(dp[i][j][k]+1ll*dp[i-1][j-1][k-l]*infr[l]%mod);
			}
	tans[1]=n;
	for(int i=2;i<=n;i++)
		tans[i]=1ll*dp[n][i][i-2]*fr[i-2]%mod;
	for(int i=1;i<=n;i++)
		printf("%lld ",tans[i]);
	return 0;
}
