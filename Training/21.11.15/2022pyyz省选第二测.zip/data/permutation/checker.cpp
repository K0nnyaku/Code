#include <iostream>
#include <cstring>
#include <cmath>
#include <cstdio>
#include <algorithm>
using namespace std;
#define N 1000050
int val[N],v[N],n,Fullmark;

int main(int argc,char *argv[])
 {
	FILE *Standard_Output = fopen(argv[3], "r");
	FILE *User_Output = fopen(argv[2], "r");
	FILE *Input = fopen(argv[1], "r");
	FILE *Score = fopen(argv[5], "w");
	FILE *Log = fopen(argv[6], "w");
	Fullmark = atoi(argv[4]);
	fscanf(Input,"%d",&n);
	for (int i=1;i<=n;i++) 
    {
        int x;
        fscanf(Input, "%d", &x);
        val[i] = x;
    }
	fscanf(User_Output,"%d",&v[1]);
    if (v[1]==-1)
     {
     	int k;fscanf(Standard_Output,"%d",&k);
     	if (k!=-1) fprintf(Score,"%d",0); else
     	  fprintf(Score,"%d",Fullmark);
     	return 0;
     }
    for (int i=2;i<=n;i++) fscanf(User_Output,"%d",&v[i]);
    for (int i=1;i<=n;i++)
     if (v[v[i]]!=val[i]) Fullmark=false;
    fprintf(Score,"%d",Fullmark);
    return 0;
 }
