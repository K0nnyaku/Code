#include<bits/stdc++.h>
#define ll long long
using namespace std;
const int N=15;
int b[N],a[N],vis[N],n; 
inline int read()
{
	int x=0,ff=1;
	char ch=getchar();
	while(!isdigit(ch)) {if(ch=='-') ff=-1;ch=getchar();}
	while(isdigit(ch)) {x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
	return x*ff;
}
inline bool check()
{
	for(int i=1;i<=n;++i) if(a[i]!=b[b[i]]) return false;
	return true;
}
inline bool dfs(int x)
{
	if(x==n)
	{
		if(check()) 
		{
			for(int i=1;i<=n;++i) printf("%d ",b[i]);
			return true;
		}
		return false;
	}
	for(int i=1;i<=n;++i)
	{
		if(!vis[i])
		{
			vis[i]=1;
			b[x+1]=i;
			if(dfs(x+1)) return true;
			vis[i]=0;
			b[x+1]=0;
		}
	}
	return  false;
}
int main()
{
	freopen("permutation.in","r",stdin);
	freopen("permutation.out","w",stdout);
	n=read();
	for(int i=1;i<=n;++i) a[i]=read();
	if(!dfs(0)) puts("-1");
	return 0;
}
