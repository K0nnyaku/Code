#include<bits/stdc++.h>
#define ll long long
using namespace std;
const int N=1e5+10;
int l[N],r[N],cnt,n,f[N];
inline int read()
{
	int x=0,ff=1;
	char ch=getchar();
	while(!isdigit(ch)) {if(ch=='-') ff=-1;ch=getchar();}
	while(isdigit(ch)) {x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
	return x*ff;
}
inline int getf(int k) {f[k]==k?k:f[k]=getf(f[k]);}
int main()
{
	freopen("interval.in","r",stdin);
	freopen("interval.out","w",stdout);
	n=read();
	for(int i=1;i<=n;++i)
	{
		int op=read(),x=read(),y=read();
		if(op==1)
		{
			f[++cnt]=cnt;
			l[cnt]=x;r[cnt]=y;
			for(int j=1;j<cnt;++j)
			{
				if((l[j]>l[cnt]&&l[j]<r[cnt])||(r[j]>l[cnt]&&r[j]<r[cnt]))
				{
					int t1=getf(j),t2=getf(cnt);
					if(t1!=t2) f[t1]=t2;
				}
			}
		}
		else 
		{
			int t1=getf(x),t2=getf(y);
			if(t1==t2) puts("YES");
			else       puts("NO");
		}
	} 
	return 0;
}

