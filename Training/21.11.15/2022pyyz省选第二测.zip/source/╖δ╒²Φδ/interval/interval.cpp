//#include<bits\stdc++.h>
#include<iostream>
#include<iomanip>
#include<cstdio>
#include<cstring>
#include<string>
#include<ctime>
#include<cmath>
#include<cctype>
#include<cstdlib>
#include<queue>
#include<deque>
#include<stack>
#include<vector>
#include<algorithm>
#include<utility>
#include<bitset>
#include<set>
#include<map>
#define ll long long
#define db double
#define INF 1000000000
#define ld long double
#define pb push_back
#define get(x) x=read()
#define gt(x) scanf("%d",&x)
#define put(x) printf("%d\n",x)
#define putl(x) printf("%lld\n",x)
#define gc(a) scanf("%s",a+1);
#define rep(p,n,i) for(RE int i=p;i<=n;++i)
#define go(x) for(int i=lin[x],tn=ver[i];i;tn=ver[i=nex[i]])
#define pii pair<int,int> 
#define F first
#define S second
#define mk make_pair
#define P 13331int
#define mod 1000000007
#define RE register
#define zz p<<1
#define yy p<<1|1
#define EPS 1e-4
using namespace std;
char buf[1<<15],*fs,*ft;
inline char getc()
{
	return (fs==ft&&(ft=(fs=buf)+fread(buf,1,1<<15,stdin),fs==ft))?0:*fs++;
}
inline int read()
{
	RE int x=0,f=1;char ch=getc();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getc();}
	while(ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getc();}
	return x*f;
}
const int MAXN=200010;
int n,cnt,top,num;
int b[MAXN];
int f[MAXN],cl[MAXN],cr[MAXN];
vector<int>g[MAXN<<2];
struct wy
{
	int op;
	int x,y;
}t[MAXN];
inline void discrete()
{
	sort(b+1,b+1+cnt);
	rep(1,cnt,i)if(i==1||b[i]!=b[i-1])b[++num]=b[i];
	rep(1,n,i)if(t[i].op==1)
	{
		t[i].x=lower_bound(b+1,b+1+num,t[i].x)-b;
		t[i].y=lower_bound(b+1,b+1+num,t[i].y)-b;
	}
}
inline int getfather(int x){return x==f[x]?x:f[x]=getfather(f[x]);}
inline void change(int p,int l,int r,int x,int w)
{
	if(g[p].size())
	{
		rep(0,g[p].size()-1,i)
		{
			int tn=getfather(g[p][i]);
			f[tn]=w;cl[w]=min(cl[tn],cl[w]);cr[w]=max(cr[w],cr[tn]);
		}
		g[p].clear();g[p].pb(w);
	}
	if(l==r)return;
	int mid=(l+r)>>1;
	if(x<=mid)change(zz,l,mid,x,w);
	else change(yy,mid+1,r,x,w);
}
inline void modify(int p,int l,int r,int L,int R,int x)
{
	if(L<=l&&R>=r){g[p].pb(x);return;}
	int mid=(l+r)>>1;
	if(L<=mid)modify(zz,l,mid,L,R,x);
	if(R>mid)modify(yy,mid+1,r,L,R,x);
}
int main()
{
	freopen("interval.in","r",stdin);
	freopen("interval.out","w",stdout);
	get(n);
	rep(1,n,i)
	{
		get(t[i].op);get(t[i].x);get(t[i].y);
		if(t[i].op==1)b[++cnt]=t[i].x,b[++cnt]=t[i].y;
	}
	discrete();
	rep(1,n,i)
	{
		if(t[i].op==1)
		{
			++top;f[top]=top;
			cl[top]=t[i].x;
			cr[top]=t[i].y;
			change(1,1,num,t[i].x,top);
			change(1,1,num,t[i].y,top);
			if(t[i].x+1<t[i].y)modify(1,1,num,t[i].x+1,t[i].y-1,top);
		}
		else
		{
			int x=getfather(t[i].x);
			int y=getfather(t[i].y);
			if(x==y||(cl[y]<cl[x]&&cr[x]<cr[y]))puts("YES");
			else puts("NO");
		}
	}
	return 0;
}

