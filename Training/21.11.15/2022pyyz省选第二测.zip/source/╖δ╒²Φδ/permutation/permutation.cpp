//#include<bits\stdc++.h>
#include<iostream>
#include<iomanip>
#include<cstdio>
#include<cstring>
#include<string>
#include<ctime>
#include<cmath>
#include<cctype>
#include<cstdlib>
#include<queue>
#include<deque>
#include<stack>
#include<vector>
#include<algorithm>
#include<utility>
#include<bitset>
#include<set>
#include<map>
#define ll long long
#define db double
#define INF 1000000000
#define ld long double
#define pb push_back
#define gt(x) scanf("%d",&x)
#define put(x) printf("%d\n",x)
#define putl(x) printf("%lld\n",x)
#define gc(a) scanf("%s",a+1);
#define rep(p,n,i) for(RE int i=p;i<=n;++i)
#define go(x) for(int i=lin[x],tn=ver[i];i;tn=ver[i=nex[i]])
#define pii pair<int,int> 
#define F first
#define S second
#define mk make_pair
#define P 13331int
#define mod 1000000007
#define RE register
#define EPS 1e-4
using namespace std;
char buf[1<<15],*fs,*ft;
inline char getc()
{
	return (fs==ft&&(ft=(fs=buf)+fread(buf,1,1<<15,stdin),fs==ft))?0:*fs++;
}
inline int read()
{
	RE int x=0,f=1;char ch=getc();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getc();}
	while(ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getc();}
	return x*f;
}
const int MAXN=1000010;
int n,cnt;
int c[MAXN],a[MAXN],vis[MAXN],ans[MAXN];
vector<int>b[MAXN],w[MAXN];
inline void get(int x)
{
	rep(0,b[x].size()-1,i)a[i+1]=b[x][i];
	int mid=(b[x].size()>>1)+1;
	ans[a[mid]]=a[1];
	for(int i=1;i<mid;++i)
	{
		ans[a[i]]=a[mid+i];
		ans[a[mid+i]]=a[i+1];
	}
}
inline void get(int x,int y)
{
	rep(0,b[x].size()-1,i)
	{
		ans[b[y][i]]=b[x][i];
		ans[b[x][i]]=i==b[x].size()-1?b[y][0]:b[y][i+1];
	}
}
int main()
{
	freopen("permutation.in","r",stdin);
	freopen("permutation.out","w",stdout);
	gt(n);
	rep(1,n,i)gt(c[i]);
	rep(1,n,i)
	{
		if(vis[i])continue;
		vis[i]=1;int x=c[i],cc=1;
		++cnt;b[cnt].pb(x);
		while(!vis[x])
		{
			vis[x]=1;x=c[x];
			b[cnt].pb(x);++cc;
		}
		w[cc].pb(cnt);
	}
	rep(1,n,i)
	{
		if(!w[i].size())continue;
		if(!(i&1))if(w[i].size()&1){puts("-1");return 0;}
		if(w[i].size()&1)
			rep(0,w[i].size()-1,j)get(w[i][j]);
		else
			for(int j=0;j<w[i].size()-1;j+=2)get(w[i][j],w[i][j+1]);
	}
	rep(1,n,i)printf("%d ",ans[i]);
	return 0;
}

